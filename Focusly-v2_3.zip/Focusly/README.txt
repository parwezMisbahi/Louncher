Focusly - build + update
------------------------
UI: app/src/main/assets/index.html (WebView). Isko browser mein bhi khol sakte ho (demo data ke saath).
Native engine (alarm, reminder, app block, lock): Core.kt / Block.kt / Phase2.kt, bridge: MainActivity.kt

Update bina uninstall: har build focusly.jks se sign hota hai (same key) aur versionCode har build pe
badhta hai, isliye naya APK purane ke upar install ho jata hai. focusly.jks ko kabhi delete/change mat karna
aur GitHub pe bhi isi file ke saath push karna.

Build: GitHub pe push karo -> Actions -> "Build Focusly APK" -> Focusly-debug-apk.
Local: gradle assembleDebug  (Gradle 8.9, JDK 17)

Block / Lock ke liye zaroori: phone Settings > Accessibility > Focusly ko ON karna hota hai.
Block system ab Docera jaisa hai: blocked app ke window ke upar overlay ("app block hai" + sirf Home button), split-screen / floating window par bhi.
Optional auto-enable: adb shell pm grant com.focusly.app android.permission.WRITE_SECURE_SETTINGS

Naya (v2.2):
- Alarm / Reminder / Goal reminder par "Poori screen block" option: fix time ke liye poori screen block (sirf emergency 5 min x 2 roz).
- Goal: category (Sehat/Padhai/Fitness/Kaam/Aur), kab se kab tak time window, target ke hisaab se reminders evenly spread; notification par "Ho gaya +N" button.
- Chalte hue block ko band/delete nahi kar sakte (UI aur native dono mein roka gaya).

v2.3:
- Block: sab installed apps ki list me se ek ya zyada apps select (Sab chuno / Clear / search).
- Daily limit rule: "roz X minute" - Focusly khud foreground time ginta hai, limit poori hote hi app block (raat 12 baje khulta).
- Goal ke saath app block: goal ka progress poora hone tak chuni apps block.
- Strict mode (Block tab): block chalte waqt Focusly ki Settings pages / uninstall band (Device Admin + settings guard).
- Blocker band ho jaye to notification aata hai (tap -> Accessibility settings).
