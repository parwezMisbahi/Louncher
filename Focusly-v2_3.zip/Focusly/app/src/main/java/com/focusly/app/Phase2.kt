package com.focusly.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Calendar

object Lock {
    fun until(c: Context) = c.getSharedPreferences("focusly", 0).getLong("lock", 0)
    fun set(c: Context, t: Long) = c.getSharedPreferences("focusly", 0).edit().putLong("lock", t).apply()
}

/** Full-screen block for a fixed time (started by an alarm / reminder / goal reminder that has "screen block" on). */
object Hold {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun left(c: Context): Long = (sp(c).getLong("hold", 0) - System.currentTimeMillis()).coerceAtLeast(0)
    fun title(c: Context): String = sp(c).getString("holdT", "") ?: ""
    fun start(c: Context, title: String, minutes: Int) {
        val m = minutes.coerceIn(1, 180)
        val end = System.currentTimeMillis() + m * 60_000L
        if (end > sp(c).getLong("hold", 0)) sp(c).edit().putLong("hold", end).putString("holdT", title).apply()
        BlockService.poke()
    }
}

/**
 * Emergency use: fixed 2 passes per day, 5 minutes each. The counter is kept per key (an app's package,
 * or "hold" for the full-screen block) and is NOT reset by deleting / re-creating a rule.
 */
object Emerg {
    const val MINUTES = 5
    const val PER_DAY = 2
    private fun sp(c: Context) = c.getSharedPreferences("focusly_em", 0)
    private fun day() = LocalDate.now().toEpochDay()
    private fun obj(c: Context, k: String): JSONObject {
        val o = try { JSONObject(sp(c).getString(k, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        if (o.optLong("d", -1) != day()) return JSONObject().put("d", day()).put("u", 0).put("p", o.optLong("p", 0))
        return o
    }
    fun left(c: Context, k: String) = (PER_DAY - obj(c, k).optInt("u", 0)).coerceAtLeast(0)
    fun active(c: Context, k: String) = obj(c, k).optLong("p", 0) > System.currentTimeMillis()
    fun anyActive(c: Context): Boolean = sp(c).all.keys.any { active(c, it) }
    @Synchronized fun use(c: Context, k: String): Boolean {
        val o = obj(c, k)
        if (o.optLong("p", 0) > System.currentTimeMillis() || o.optInt("u", 0) >= PER_DAY) return false
        o.put("u", o.optInt("u", 0) + 1).put("p", System.currentTimeMillis() + MINUTES * 60_000L)
        sp(c).edit().putString(k, o.toString()).apply()
        return true
    }
}

/**
 * ws/we = reminder window (minutes of day). When [rem] is on, the day's reminders are spread evenly over the
 * window so the goal is finished by its end (e.g. 8 glasses 07:00-23:00 -> a reminder every 2 hours).
 */
data class Goal(val id: Int, val name: String, val unit: String, val target: Int, val step: Int,
                val progress: Int, val day: Long, val streak: Int, val lastDone: Long,
                val cat: String = "", val rem: Boolean = false, val ws: Int = 7 * 60, val we: Int = 23 * 60, val blk: Int = 0,
                /** apps blocked until progress reaches [ln] (0 = target) */ val lp: Set<String> = emptySet(), val ln: Int = 0)

object GoalStore {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun load(c: Context): List<Goal> {
        val a = JSONArray(sp(c).getString("goals", "[]")); val today = LocalDate.now().toEpochDay()
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val g = Goal(o.getInt("id"), o.getString("n"), o.getString("u"), o.getInt("t"), o.getInt("s"), o.getInt("p"), o.getLong("d"), o.getInt("k"), o.getLong("l"),
                o.optString("c", ""), o.optBoolean("r", false), o.optInt("ws", 420), o.optInt("we", 1380), o.optInt("bk", 0),
                o.optString("lp", "").split(",").filter { s -> s.isNotEmpty() }.toSet(), o.optInt("ln", 0))
            if (g.day != today) g.copy(progress = 0, day = today) else g
        }
    }
    fun save(c: Context, l: List<Goal>) = sp(c).edit().putString("goals", JSONArray(l.map {
        JSONObject().put("id", it.id).put("n", it.name).put("u", it.unit).put("t", it.target).put("s", it.step)
            .put("p", it.progress).put("d", it.day).put("k", it.streak).put("l", it.lastDone)
            .put("c", it.cat).put("r", it.rem).put("ws", it.ws).put("we", it.we).put("bk", it.blk)
            .put("lp", it.lp.joinToString(",")).put("ln", it.ln)
    }).toString()).apply()
}

/** Goal reminders spread over the goal's time window. */
object GoalSched {
    private const val MAX_SLOTS = 48
    private const val BASE = 30_000_000

    fun slots(g: Goal) = minOf(MAX_SLOTS, maxOf(1, (g.target + g.step - 1) / g.step))

    /** Minute of day of slot [i]. */
    fun slotMin(g: Goal, i: Int): Int {
        val we = if (g.we > g.ws) g.we else g.we + 1440
        return (g.ws + (we - g.ws) * i / slots(g)) % 1440
    }

    private fun nid(gid: Int, slot: Int) = BASE + gid * 100 + slot
    private fun pi(c: Context, gid: Int, slot: Int) = PendingIntent.getBroadcast(c, nid(gid, slot),
        Intent(c, Rx::class.java).setAction("FIRE").putExtra("k", "g").putExtra("id", gid).putExtra("slot", slot),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun cancel(c: Context, g: Goal) {
        val am = c.getSystemService(AlarmManager::class.java)
        for (s in 0 until MAX_SLOTS) am.cancel(pi(c, g.id, s))
    }

    private fun nextTime(min: Int): Long {
        val t = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, min / 60); set(Calendar.MINUTE, min % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (t.timeInMillis <= System.currentTimeMillis() + 1000) t.add(Calendar.DAY_OF_YEAR, 1)
        return t.timeInMillis
    }

    private fun arm(c: Context, g: Goal, slot: Int) {
        val p = pi(c, g.id, slot)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(nextTime(slotMin(g, slot)), p), p)
    }

    fun armAll(c: Context) {
        for (g in GoalStore.load(c)) {
            cancel(c, g)
            if (g.rem) for (s in 0 until slots(g)) arm(c, g, s)
        }
    }

    fun fire(c: Context, i: Intent) {
        val gid = i.getIntExtra("id", 0); val slot = i.getIntExtra("slot", 0)
        val g = GoalStore.load(c).find { it.id == gid } ?: return
        if (!g.rem || slot >= slots(g)) return
        arm(c, g, slot) // same time again tomorrow
        val expected = minOf(g.target, (slot + 1) * g.step)
        if (g.progress >= expected) return // already ahead of schedule -> no reminder
        val n = nid(gid, slot)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fg", "Goal reminders", NotificationManager.IMPORTANCE_HIGH))
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val done = PendingIntent.getBroadcast(c, n + 50_000_000, Intent(c, Rx::class.java).setAction("GDONE").putExtra("k", "g").putExtra("id", gid).putExtra("slot", slot), flags)
        val open = PendingIntent.getActivity(c, n, Intent(c, MainActivity::class.java), flags)
        val left = g.target - g.progress
        nm.notify(n, NotificationCompat.Builder(c, "fg").setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("🎯 " + g.name)
            .setContentText("${g.progress}/${g.target} ${g.unit} • abhi ${minOf(g.step, left)} ${g.unit} karo (${left} baaki)")
            .setAutoCancel(true).setContentIntent(open).setTimeoutAfter(60 * 60_000L)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            .addAction(0, "Ho gaya +${g.step}", done).build())
        if (g.blk > 0) Hold.start(c, "🎯 " + g.name, g.blk)
    }

    /** "Ho gaya" button on the notification: adds one step to today's progress. */
    fun done(c: Context, i: Intent) {
        val gid = i.getIntExtra("id", 0); val slot = i.getIntExtra("slot", 0)
        c.getSystemService(NotificationManager::class.java).cancel(nid(gid, slot))
        val today = LocalDate.now().toEpochDay()
        GoalStore.save(c, GoalStore.load(c).map {
            if (it.id != gid) it else {
                val np = it.progress + it.step
                var g = it.copy(progress = np, day = today)
                if (it.progress < it.target && np >= it.target) g = g.copy(streak = if (it.lastDone == today - 1) it.streak + 1 else 1, lastDone = today)
                g
            }
        })
    }
}

/** Goal-linked block: the goal's apps stay blocked until its progress reaches [need]. */
fun Goal.need() = if (ln > 0) ln else target
fun Goal.linkActive(): Boolean {
    if (lp.isEmpty() || progress >= need()) return false
    val c = Calendar.getInstance()
    val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    return now >= (if (rem) ws else 0)
}

/** Foreground time per app per day (counted by the accessibility service, no extra permission). */
object Usage {
    private fun sp(c: Context) = c.getSharedPreferences("focusly_usage", 0)
    private fun day() = LocalDate.now().toEpochDay()
    private fun obj(c: Context): JSONObject {
        val o = try { JSONObject(sp(c).getString("u", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        return if (o.optLong("_d", -1) == day()) o else JSONObject().put("_d", day())
    }
    fun get(c: Context, pkg: String): Long = obj(c).optLong(pkg, 0)
    @Synchronized fun add(c: Context, pkg: String, ms: Long) {
        val o = obj(c)
        o.put(pkg, o.optLong(pkg, 0) + ms)
        sp(c).edit().putString("u", o.toString()).apply()
    }
}

/** Strict mode: while a block is running, Focusly's own Settings pages (accessibility, app info, uninstall, device admin) are shut. */
object Strict {
    fun wanted(c: Context) = c.getSharedPreferences("focusly", 0).getBoolean("strict", false)
    fun set(c: Context, on: Boolean) = c.getSharedPreferences("focusly", 0).edit().putBoolean("strict", on).apply()
}
