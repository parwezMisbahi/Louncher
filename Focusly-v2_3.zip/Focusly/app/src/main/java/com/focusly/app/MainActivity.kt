package com.focusly.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.app.admin.DeviceAdminReceiver
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

fun newId() = (System.currentTimeMillis() % 100000).toInt() + 1

/**
 * The whole UI lives in assets/index.html (same design as the preview).
 * Kotlin only hosts it and exposes the real alarm / reminder / block / lock engine
 * to the page through the "Native" JavaScript bridge.
 */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var loaded = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setBars(true)
        web = WebView(this).apply {
            setBackgroundColor(0xFF0B1517.toInt())
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = false
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                textZoom = 100
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean = true
                override fun shouldInterceptRequest(v: WebView?, r: WebResourceRequest?): WebResourceResponse? {
                    val u = r?.url ?: return null
                    if (u.host == "appicon.focusly") return appIcon(u.lastPathSegment?.removeSuffix(".png") ?: "")
                    return null
                }
                override fun onPageFinished(v: WebView?, url: String?) { loaded = true }
            }
            addJavascriptInterface(Bridge(), "Native")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (!BlockService.connected && Blocker.anyConfigured(this)) Blocker.tryEnableService(this)
        if (loaded) web.evaluateJavascript("window.focuslyReload&&focuslyReload()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.focuslyBack?focuslyBack():false") { if (it != "true") finish() }
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }

    private fun adminOn() = try { getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(this, AdminRx::class.java)) } catch (_: Exception) { false }

    @Suppress("DEPRECATION")
    private fun setBars(dark: Boolean) {
        val col = if (dark) 0xFF0B1517.toInt() else 0xFFEEF5F3.toInt()
        window.statusBarColor = col
        window.navigationBarColor = col
        var f = window.decorView.systemUiVisibility
        f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
    }

    private fun appIcon(pkg: String): WebResourceResponse {
        return try {
            val d = packageManager.getApplicationIcon(pkg)
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 96, 96); d.draw(Canvas(bmp))
            val out = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            WebResourceResponse("image/png", null, 200, "OK", mapOf("Cache-Control" to "max-age=3600"), ByteArrayInputStream(out.toByteArray()))
        } catch (e: Exception) {
            WebResourceResponse("image/png", null, 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        }
    }

    inner class Bridge {
        @JavascriptInterface fun getState(): String {
            val c = applicationContext
            return JSONObject()
                .put("alarms", JSONArray(Store.alarms(c).map {
                    JSONObject().put("id", it.id).put("h", it.hour).put("m", it.minute)
                        .put("d", JSONArray(it.days.sorted())).put("l", it.label).put("on", it.on).put("bk", it.blk)
                }))
                .put("rems", JSONArray(Store.reminders(c).map {
                    JSONObject().put("id", it.id).put("t", it.title).put("at", it.at).put("daily", it.daily).put("on", it.on).put("bk", it.blk)
                }))
                .put("rules", JSONArray(Store.rules(c).map {
                    JSONObject().put("id", it.id).put("pkg", it.pkg).put("n", it.name).put("s", it.start).put("e", it.end)
                        .put("d", JSONArray(it.days.sorted())).put("on", it.on)
                        .put("lim", it.lim).put("used", (Usage.get(c, it.pkg) / 60_000L).toInt())
                }))
                .put("goals", JSONArray(GoalStore.load(c).map {
                    JSONObject().put("id", it.id).put("n", it.name).put("u", it.unit).put("t", it.target).put("st", it.step)
                        .put("p", it.progress).put("day", it.day).put("streak", it.streak).put("last", it.lastDone)
                        .put("c", it.cat).put("r", it.rem).put("ws", it.ws).put("we", it.we).put("bk", it.blk)
                        .put("lp", JSONArray(it.lp.toList())).put("ln", it.ln)
                }))
                .put("strict", Strict.wanted(c) && adminOn())
                .put("lockUntil", Lock.until(c))
                .toString()
        }

        @JavascriptInterface fun save(json: String) {
            val c = applicationContext
            val o = JSONObject(json)
            fun days(a: JSONArray) = (0 until a.length()).map { a.getInt(it) }.toSet()
            fun <T> arr(k: String, f: (JSONObject) -> T): List<T> {
                val a = o.optJSONArray(k) ?: return emptyList()
                return (0 until a.length()).map { f(a.getJSONObject(it)) }
            }
            // cancel everything that was scheduled, store the new lists, schedule again
            Store.alarms(c).forEach { Sched.cancel(c, "a", it.id) }
            Store.reminders(c).forEach { Sched.cancel(c, "r", it.id) }
            GoalStore.load(c).forEach { GoalSched.cancel(c, it) }
            Store.saveAlarms(c, arr("alarms") { Alarm(it.getInt("id"), it.getInt("h"), it.getInt("m"), days(it.getJSONArray("d")), it.optString("l", ""), it.getBoolean("on"), it.optInt("bk", 0).coerceIn(0, 180)) })
            Store.saveReminders(c, arr("rems") { Reminder(it.getInt("id"), it.getString("t"), it.getLong("at"), it.getBoolean("daily"), it.getBoolean("on"), it.optInt("bk", 0).coerceIn(0, 180)) })
            // A block that is running right now can NOT be switched off, deleted or shortened from the UI.
            val activeOld = Store.rules(c).filter { it.on && isActive(it, c) }
            val oldGoals = GoalStore.load(c)
            val incoming = arr("rules") { Rule(it.getInt("id"), it.getString("pkg"), it.getString("n"), it.getInt("s"), it.getInt("e"), days(it.getJSONArray("d")), it.getBoolean("on"), it.optInt("lim", 0).coerceIn(0, 1440)) }
            val kept = incoming.map { r -> activeOld.find { it.id == r.id } ?: r } + activeOld.filter { o -> incoming.none { it.id == o.id } }
            Store.saveRules(c, kept)
            val newGoals = arr("goals") { Goal(it.getInt("id"), it.getString("n"), it.optString("u", ""), it.getInt("t"), it.getInt("st"), it.getInt("p"), it.getLong("day"), it.getInt("streak"), it.getLong("last"),
                it.optString("c", ""), it.optBoolean("r", false), it.optInt("ws", 420), it.optInt("we", 1380), it.optInt("bk", 0).coerceIn(0, 180),
                (it.optJSONArray("lp")?.let { l -> (0 until l.length()).map { k -> l.getString(k) } } ?: emptyList()).toSet(), it.optInt("ln", 0)) }
            // a goal whose app-block is running can not be deleted or loosened until the goal is done
            val lockedGoals = oldGoals.filter { it.linkActive() }
            val goalsKept = newGoals.map { g -> lockedGoals.find { it.id == g.id }?.let { o -> g.copy(lp = o.lp, ln = o.ln, rem = o.rem, ws = o.ws) } ?: g } +
                lockedGoals.filter { o -> newGoals.none { it.id == o.id } }
            GoalStore.save(c, goalsKept)
            Lock.set(c, maxOf(o.optLong("lockUntil", 0), Lock.until(c))) // a running lock can not be shortened
            Sched.armAll(c)
        }

        @JavascriptInterface fun apps(): String {
            val pm = packageManager
            val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
            return JSONArray(l.map { JSONObject().put("p", it.first).put("n", it.second) }).toString()
        }

        @JavascriptInterface fun strictOn(): Boolean = Strict.wanted(applicationContext) && adminOn()

        /** "ok", "admin" (Android asks to activate device admin first), "locked" (a block is running) */
        @JavascriptInterface fun setStrict(on: Boolean): String {
            val c = applicationContext
            if (on) {
                Strict.set(c, true)
                if (!adminOn()) {
                    runOnUiThread { try { startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(c, AdminRx::class.java))
                        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Strict mode: block chalte waqt Focusly ko uninstall hone se bachata hai.")) } catch (_: Exception) {} }
                    return "admin"
                }
                return "ok"
            }
            if (Blocker.anyActive(c)) return "locked"
            Strict.set(c, false)
            try { c.getSystemService(DevicePolicyManager::class.java).removeActiveAdmin(ComponentName(c, AdminRx::class.java)) } catch (_: Exception) {}
            return "ok"
        }

        @JavascriptInterface fun accOn(): Boolean = accessibilityOn(applicationContext)

        @JavascriptInterface fun openAccessibility() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface fun theme(dark: Boolean) { runOnUiThread { setBars(dark) } }
    }
}

/** Empty device admin: while it is active Android refuses to uninstall Focusly (used by Strict mode). */
class AdminRx : DeviceAdminReceiver()
