package com.focusly.app

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Notification-bar tile: shows a live countdown (phone lock / focus timer / screen block / active rule). */
class CountTile : TileService() {
    private val h = Handler(Looper.getMainLooper())
    private val loop = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000L) } }

    override fun onStartListening() { h.removeCallbacks(loop); h.post(loop) }
    override fun onStopListening() { h.removeCallbacks(loop) }

    override fun onClick() {
        val i = Intent(applicationContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 22, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            else @Suppress("DEPRECATION") startActivityAndCollapse(i)
        } catch (_: Throwable) {}
    }

    private fun refresh() {
        val t = qsTile ?: return
        val c = applicationContext
        var left = 0L
        var what = ""
        fun cand(ms: Long, w: String) { if (ms > 0 && (left == 0L || ms < left)) { left = ms; what = w } }
        try { cand(Lock.until(c) - System.currentTimeMillis(), "Phone lock") } catch (_: Throwable) {}
        try { val p = Pomo.st(c); if (p.running) cand(p.leftMs, if (p.focus) "Focus" else "Break") } catch (_: Throwable) {}
        try { cand(Hold.left(c), "Screen block") } catch (_: Throwable) {}
        try { Store.rules(c).filter { ruleBlocking(it, c) }.forEach { cand(ruleLeftPublic(it), "Block rule") } } catch (_: Throwable) {}
        t.state = if (left > 0) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = if (left > 0) Blocker.format(left) else "Focusly"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (left > 0) what else "No timer"
        t.updateTile()
    }
}

/** One-time cleanup: the location feature was removed, so drop saved places and every place link. */
object NoLoc {
    fun run(c: Context) {
        try { if (Places.all(c).isNotEmpty()) Places.save(c, emptyList()) } catch (_: Throwable) {}
        try { val rs = Store.rules(c); if (rs.any { it.pls.isNotEmpty() }) Store.saveRules(c, rs.map { it.copy(pls = emptyList()) }) } catch (_: Throwable) {}
        try { Lock.setPls(c, emptyList()) } catch (_: Throwable) {}
    }
}
