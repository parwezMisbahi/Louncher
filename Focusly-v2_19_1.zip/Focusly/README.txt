Focusly - build + update
------------------------
UI: app/src/main/assets/index.html (WebView). Isko browser mein bhi khol sakte ho (demo data ke saath).
Native engine (alarm, reminder, app block, lock): Core.kt / Block.kt / Phase2.kt, bridge: MainActivity.kt

Update bina uninstall: har build focusly.jks se sign hota hai (same key) aur versionCode har build pe
badhta hai, isliye naya APK purane ke upar install ho jata hai. focusly.jks ko kabhi delete/change mat karna
aur GitHub pe bhi isi file ke saath push karna.

Build: GitHub pe push karo -> Actions -> "Build Focusly APK" -> Focusly-debug-apk.
Local: gradle assembleDebug  (Gradle 8.11.1, JDK 17)

Block / Lock ke liye zaroori: phone Settings > Accessibility > Focusly ko ON karna hota hai.
Block system ab Docera jaisa hai: blocked app ke window ke upar overlay ("app block hai" + sirf Home button), split-screen / floating window par bhi.
Optional auto-enable: adb shell pm grant com.focusly.app android.permission.WRITE_SECURE_SETTINGS

Naya (v2.2):
- Alarm / Reminder / Goal reminder par "Poori screen block" option: fix time ke liye poori screen block (sirf emergency 5 min x 2 roz).
- Goal: category (Sehat/Padhai/Fitness/Kaam/Aur), kab se kab tak time window, target ke hisaab se reminders evenly spread; notification par "Ho gaya +N" button.
- Chalte hue block ko band/delete nahi kar sakte (UI aur native dono mein roka gaya).

v2.3:
- Block: sab installed apps ki list me se ek ya zyada apps select (Sab chuno / Clear / search).
- Daily limit rule: "roz X minute" - Focusly khud foreground time ginta hai, limit poori hote hi app block (raat 12 baje khulta).
- Goal ke saath app block: goal ka progress poora hone tak chuni apps block.
- Strict mode (Block tab): block chalte waqt Focusly ki Settings pages / uninstall band (Device Admin + settings guard).
- Blocker band ho jaye to notification aata hai (tap -> Accessibility settings).

v2.4 (HyperOS fix):
- KeepService: foreground notification + sticky restart, so recents se hatane par blocker / alarm band na ho.
- Home / Lock tab par "Phone settings" card: Autostart, Battery (No restrictions), App info shortcuts.
- Boot / app-update par alarms + service dobara chalu.
Phone mein ek baar zaroor: Autostart ON, Battery No restrictions, recents mein Focusly lock, App info > menu > Allow restricted settings.

v2.4 update: KeepService ab Docera jaisa 2nd blocker bhi hai (Usage access + Display over other apps).
Accessibility band ho (recents se hatane par) tab bhi blocked app par overlay aata hai, aur screen-block / daily limit chalte hain.
Home / Lock tab ke card se: Usage access, Overlay, Autostart, Battery, App info.

"Kabhi block nahi" apps: Block tab / Lock tab mein "+ App jodo". Ye apps Phone Lock, "Saare apps" rules, poori screen block aur goal "sab apps" block se bachte hain
(padhne wale apps ke liye). Kisi app ka apna alag rule ho to wo lagta hai. Block chalte waqt list mein naye apps nahi jud sakte (sirf hat sakte hain).

Settings: header ke upar naya Settings button. Phone settings (Usage/Overlay/Autostart/Battery/App info), Strict mode aur "Kabhi block nahi" apps ab wahin hain.

v2.5 (Plan B: galti se laga block hatana):
- "Sab block hatao": har 2 ghante mein 1 baar, 5 minute ke liye POORA block system band (app rules, daily limit, goal link, Phone lock, poori screen block).
- Block tab ke upar card + block screen par button (2 baar tap karna padta hai). Window ke dauran rule off / delete ho sakta hai, Phone lock hat sakta hai, Strict mode band ho sakta hai.
- 5 min baad block wapas lag jata hai. Agla window pehle window shuru hone ke 2 ghante baad khulta hai.
- Time badalna ho to Phase2.kt mein object Gap: MINUTES (5) aur EVERY_MIN (120).

v2.6 (Jagah / location wale rules):
- Block tab > "Jagahen": jagah jodo (naam + "Abhi yahan ki location lo" + radius 100-500 m).
- Schedule rule banate waqt "Jagah (optional)" chuno: rule ke time par block lagta hai aur us jagah pahunchte hi unblock ho jata hai (us din ke window ke liye). Window khatam hone par bhi block hat jata hai.
- Use 1 (namaz): "Saare apps" + 20 minute ka time + masjid ki jagah. Use 2 (class): social media apps + subah se raat tak ka time + class ki jagah: class pahunche to unblock, nahi gaye to din bhar block.
- Location check sirf tab chalta hai jab koi jagah-wala block lag raha ho (pehle 10 min har 15 sec, phir har 60 sec) taaki battery kam lage.
- Permission: Location ke liye "Hamesha allow" (Allow all the time) dena zaroori hai, aur phone ki Location (GPS) ON honi chahiye.
- Block chalte waqt jagah edit/delete nahi ho sakti (warna jagah apne paas move karke cheating ho jati). "Sab block hatao" window mein sab ho sakta hai.

v2.7 (Block jagah + Unblock jagah):
- Rule mein har jagah ke liye 3 option: Koi nahi / Unblock / Block.
- Sirf Unblock jagah: window mein block rehta hai, wahan pahunchte hi unblock (us din ke window ke liye).
- Block jagah chuni ho: app sirf us jagah ke andar block hota hai (window ke time mein). Bahar nikalte hi block hat jata hai.
- Dono ek saath: UNBLOCK KO PRIORITY. Unblock jagah ke andar block jagah disturb nahi karti (jaise bade Block area ke andar chhota Unblock area).
- Block-jagah wale rule ka window chalte waqt rule edit/delete nahi hota (bahar hone par bhi). "Sab block hatao" window mein sab ho sakta hai.
- Location dikhne band ho jaye (GPS off / permission hati) to Block-jagah wale rule block nahi karte.

v2.8 (3 tarah ka location system, sab time ke andar):
- Rule mein har jagah ke liye: Yahin block / Yahin unblock / Pahunchne par unblock.
  1) Yahin block: sirf us jagah ke andar app block, bahar nikalte hi khul jata hai.
  2) Yahin unblock: sirf us jagah par app khulega, baaki sab jagah (time ke andar) block. Jagah chhodte hi phir block.
  3) Pahunchne par unblock: block lagta hai aur time se bhi khulta hai, ya us jagah pahunchte hi khul jata hai (us window ke liye).
- Phone Lock ke liye bhi "Is jagah pahunchte hi unblock" (time se ya jagah se, jo pehle ho).
- Priority: Unblock/Pahunchne wali jagah hamesha Block jagah se upar.
- Purane v2.7 ke "Unblock" rule ab "Yahin unblock" (live) maane jate hain.

v2.9 (location fix):
- Background location pakka: KeepService ab "Hamesha allow" milte hi foreground type "location" leta hai (Android 14).
- Location permission: normal allow ke turant baad "Hamesha allow" khud poochta hai.
- GPS + Network + Fused (Android 12+) teeno se fix; purana cached fix bhi use hota hai; accuracy limit 300 -> 500 m.
- Block tab > Jagahen > "Location check" button: permission, GPS, last fix, jagah se doori, rule ka status dikhata hai (debug ke liye).

v2.10 (custom numbers):
- Jahan number ke preset buttons the wahan ab "Ya khud likho" box bhi hai: jagah ka radius (meter, 10-5000), poori screen block (minute, max 180), Phone Lock (minute, max 1440). Daily limit pehle se khud likhne wali thi.

v2.11: jagah radius minimum 3 m (preset 3 m / 10 m bhi), chhote radius par GPS noise ke liye thoda slack.

v2.12 (location band = BLOCK):
- Location band / GPS off / permission nahi / 3 min tak fix nahi: teeno location system (Yahin block, Yahin unblock, Pahunchne par unblock) mein block hi rahega. Pehle band karne par sab unblock ho jata tha.
- Location wapas on hone par jab tak naya fix nahi milta, status "unknown" = block. Fix aate hi sahi output (andar/bahar) lagta hai.
- Notification bar tile "Focusly location": ON = location allow (phone ka Location on/open karta hai), OFF = Focusly location use nahi karega -> location rules block. Jodna: Block tab > Jagahen > "Notification tile" (Android 13+) ya panel > Edit.
- Block tab > Jagahen mein "Location: ON/OFF" button bhi hai (tile jaisa hi).

v2.13:
- "Kabhi block nahi" apps ab sach mein kabhi block nahi hote: kisi app ka apna rule / daily limit bhi unpar nahi lagta.
- Block rule mein "Fix date" (se - tak, jaise 12-10-2026 se 20-10-2026) aur "Beech mein gap" (roz ke kuch ghante jab block nahi lagta; ek se zyada gap ho sakte hain). Time window, din aur jagah ke saath mil kar chalta hai.
- Date range chalte waqt rule gap mein bhi edit/delete nahi hota ("Sab block hatao" window ko chhod kar).

v2.14: 'Kabhi block nahi' list ke apps block-wale app picker mein dikhte hi nahi (galti se chun hi nahi sakte). Native side pehle se (v2.13) har block se bachata hai.

v2.15 (Phone Lock + jagah):
- Phone Lock lagate waqt har jagah ke liye: Yahin lock / Yahin unlock / Pahunchne par unlock (rules jaisa hi, sab lock ke time ke andar).
- Yahin lock: phone sirf us jagah par lock, bahar nikalte hi khul jata hai. Yahin unlock: phone sirf us jagah par chalega, baaki jagah lock. Pahunchne par unlock: pahunchte hi lock khatam.
- Unlock ko priority. Location band / GPS off / fix nahi = LOCK (kabhi unlock nahi). Naya fix aane par sahi status.

v2.16 (Play Store): targetSdk/compileSdk 36, AGP 8.10.1 + Gradle 8.11.1, signed release AAB workflow (.github/workflows/release.yml), edge-to-edge insets, back button opt-out. Details: PLAY_STORE.txt

v2.17 (location ON = kaam, OFF = aakhri status):
- Location ON: rule / Phone Lock apni jagah ke hisaab se block ya unblock karta hai.
- Location OFF / GPS off / tile OFF / permission nahi: jo aakhri status location ON ke waqt tha wahi rehta hai (block tha to block, unblock tha to unblock). v2.12 ka "off = block" hata diya. Sirf jab ab tak koi location check hua hi nahi, tab block.
- Chhote radius ke liye accuracy ka hisaab: andar maanne ke liye radius + abhi ki GPS accuracy (max 30 m) + jagah save karte waqt ki accuracy (max 30 m). Isse 3-20 m ka radius bhi "hamesha bahar" nahi padhta.

v2.18:
- Focus timer (Pomodoro): Phone Lock tab > "Focus timer". Focus / break / round apne hisaab se (custom number). Focus mein sab apps block ("Kabhi block nahi" apps, Phone, Home, Focusly chalte hain), break mein khula. Focus chalte waqt band nahi hota. Phase badalne par notification.
- Quick Settings tile "Focus mode" (panel > Edit) aur home-screen widget "Focusly Focus": ek tap par ek focus (Settings mein minute set).
- Unblock mein rukawat: Emergency aur "Sab block hatao" par pehle intezaar (default 2 min) phir ek jumla type karna (paste nahi). Settings > "Unblock mein rukawat" se badalo; block chalte waqt kam nahi ho sakta.

v2.19: naya app icon (timer / gauge). Play Store ke liye store/icon-512.png.

v2.19.1: build fix - AGP 8.7.3 / Gradle 8.9 / SDK 35 (v2.16-2.19 ka AGP 8.10.1 Gradle 8.9 par fail ho raha tha). Play ke liye PLAY_STORE.txt dekho.
