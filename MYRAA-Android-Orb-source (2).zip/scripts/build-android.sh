#!/usr/bin/env bash
# Linux/GitHub Actions equivalent of scripts/build-android.ps1 (orb avatar, no 3D model).
# Needs: node, JDK 21, zip, python3, and ANDROID_HOME with platform 35 + build-tools 35.0.0.
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
: "${ANDROID_HOME:?Set ANDROID_HOME to an Android SDK with platform 35 and build-tools 35.0.0}"
BT="$ANDROID_HOME/build-tools/35.0.0"
AJAR="$ANDROID_HOME/platforms/android-35/android.jar"
for f in "$AJAR" "$BT/aapt2" "$BT/d8" "$BT/zipalign" "$BT/apksigner"; do [ -e "$f" ] || { echo "Missing build prerequisite: $f" >&2; exit 1; }; done
command -v javac >/dev/null || { echo "javac not found (JDK 21 required)" >&2; exit 1; }

# 1. Neutral launcher icon if none exists (replaces ensure-build-icons.ps1)
mkdir -p build
if [ ! -f build/icon.png ]; then
python3 - <<'PY'
import zlib, struct
N = 256
bg = (15, 22, 27); fg = (142, 225, 219)
rows = []
def inM(x, y):
    # blocky letter "M"
    if not (48 <= y <= 208): return False
    if 52 <= x <= 84 or 172 <= x <= 204: return True
    if 84 < x < 128 and abs((x - 84) - (y - 48) * 44 / 80) < 16 and y <= 128: return True
    if 128 <= x < 172 and abs((172 - x) - (y - 48) * 44 / 80) < 16 and y <= 128: return True
    return False
for y in range(N):
    row = bytearray([0])
    for x in range(N): row += bytes(fg if inM(x, y) else bg)
    rows.append(bytes(row))
raw = b''.join(rows)
def chunk(t, d):
    c = struct.pack('>I', len(d)) + t + d
    return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', N, N, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b'')
open('build/icon.png', 'wb').write(png)
PY
fi

# 2. Web assets + personality
npx --no-install vite build --config vite.mobile.config.ts
ASSETS="$ROOT/android/app/src/main/assets"
mkdir -p "$ASSETS"
node --import tsx scripts/export-mobile-personality.ts

# 3. Java -> DEX
B="$ROOT/android/app/build/local-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$B/classes" "$B/dex" "$B/res/drawable"
mapfile -t SRC < <(find android/app/src/main/java -name '*.java')
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -classpath "$AJAR" -d "$B/classes" "${SRC[@]}"
jar --create --file "$B/classes.jar" -C "$B/classes" .
"$BT/d8" --lib "$AJAR" --min-api 26 --output "$B/dex" "$B/classes.jar"

# 4. Resources + assets -> unsigned APK, then add DEX
cp build/icon.png "$B/res/drawable/myraa_icon.png"
"$BT/aapt2" compile --dir "$B/res" -o "$B/resources.zip"
"$BT/aapt2" link --manifest android/app/src/main/AndroidManifest.xml -I "$AJAR" -A "$ASSETS" \
  --min-sdk-version 26 --target-sdk-version 35 -o "$B/unsigned.apk" "$B/resources.zip"
( cd "$B/dex" && zip -q -j "$B/unsigned.apk" ./*.dex )

# 5. Align + sign
"$BT/zipalign" -f -p 4 "$B/unsigned.apk" "$B/aligned.apk"
# Fixed signing key committed in the repo so every build can update the previous install.
KS="$ROOT/android/signing/myraa.keystore"
[ -f "$KS" ] || { echo "Missing $KS - the signing key must be in the repo (android/signing/myraa.keystore)" >&2; exit 1; }
mkdir -p artifacts/android
APK="artifacts/android/MYRAA-Mobile-1.0.0-rc.5-private.apk"
"$BT/apksigner" sign --ks "$KS" --ks-key-alias myraa --ks-pass pass:myraa-sign-2026 --key-pass pass:myraa-sign-2026 --out "$APK" "$B/aligned.apk"
"$BT/apksigner" verify --verbose "$APK"
sha256sum "$APK"
echo "Android candidate: $APK"
