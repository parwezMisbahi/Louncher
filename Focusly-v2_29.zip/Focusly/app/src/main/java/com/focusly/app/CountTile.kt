package com.focusly.app

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Notification-bar tile: shows a live countdown (phone lock / focus timer / screen block / active rule). */
class CountTile : TileService() {
    private val h = Handler(Looper.getMainLooper())
    private val loop = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000L) } }

    override fun onStartListening() { h.removeCallbacks(loop); h.post(loop) }
    override fun onStopListening() { h.removeCallbacks(loop) }

    override fun onClick() {
        val i = Intent(applicationContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 22, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            else @Suppress("DEPRECATION") startActivityAndCollapse(i)
        } catch (_: Throwable) {}
    }

    /** Draws the countdown as the tile icon: two short lines inside the circle (e.g. 11h / 27m). */
    private fun timeIcon(top: String, bottom: String): Icon {
        val size = 128
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = 56f; cv.drawText(top, size / 2f, 56f, p)
        p.textSize = 48f; cv.drawText(bottom, size / 2f, 110f, p)
        return Icon.createWithBitmap(bmp)
    }

    private fun refresh() {
        val t = qsTile ?: return
        val c = applicationContext
        var left = 0L
        var what = ""
        fun cand(ms: Long, w: String) { if (ms > 0 && (left == 0L || ms < left)) { left = ms; what = w } }
        try { cand(Lock.until(c) - System.currentTimeMillis(), "Phone lock") } catch (_: Throwable) {}
        try { val p = Pomo.st(c); if (p.running) cand(p.leftMs, if (p.focus) "Focus" else "Break") } catch (_: Throwable) {}
        try { cand(Hold.left(c), "Screen block") } catch (_: Throwable) {}
        try { Store.rules(c).filter { ruleBlocking(it, c) }.forEach { cand(ruleLeftPublic(it), "Block rule") } } catch (_: Throwable) {}
        t.state = if (left > 0) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (left > 0) {
            val sec = (left + 999L) / 1000L
            val hh = sec / 3600; val mm = (sec % 3600) / 60; val ss = sec % 60
            val (a, b) = if (hh > 0) Pair("${hh}h", "${mm}m") else if (mm > 0) Pair("${mm}m", "${ss}s") else Pair("$ss", "sec")
            t.icon = timeIcon(a, b)
            t.label = what
            if (Build.VERSION.SDK_INT >= 29) t.subtitle = Blocker.format(left)
        } else {
            t.icon = Icon.createWithResource(this, R.drawable.ic_tile)
            t.label = "Focusly"
            if (Build.VERSION.SDK_INT >= 29) t.subtitle = "No timer"
        }
        t.updateTile()
    }
}

/** One-time cleanup: the location feature was removed, so drop saved places and every place link. */
object NoLoc {
    fun run(c: Context) {
        try { if (Places.all(c).isNotEmpty()) Places.save(c, emptyList()) } catch (_: Throwable) {}
        try { val rs = Store.rules(c); if (rs.any { it.pls.isNotEmpty() }) Store.saveRules(c, rs.map { it.copy(pls = emptyList()) }) } catch (_: Throwable) {}
        try { Lock.setPls(c, emptyList()) } catch (_: Throwable) {}
    }
}
