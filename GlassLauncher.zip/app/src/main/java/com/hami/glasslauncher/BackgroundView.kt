package com.hami.glasslauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class BackgroundView(context: Context) : View(context) {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val listener: () -> Unit = { invalidate() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Backdrop.addListener(listener)
    }

    override fun onDetachedFromWindow() {
        Backdrop.removeListener(listener)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        Backdrop.setScreen(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        val b = Backdrop.bitmap ?: return
        canvas.drawBitmap(b, Backdrop.matrix, paint)
        if (Backdrop.dim > 0f) {
            canvas.drawColor(Color.argb((Backdrop.dim * 255).toInt(), 0, 0, 0))
        }
    }
}
