package com.hami.glasslauncher

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.Shader
import kotlin.math.max

/**
 * Shared wallpaper + glass style. Every GlassView samples this bitmap
 * (in screen coordinates) to fake the "refraction" of what is behind it.
 */
object Backdrop {
    var bitmap: Bitmap? = null
        private set
    var small: Bitmap? = null
        private set
    var shader: BitmapShader? = null
        private set

    val matrix = Matrix()
    val smallMatrix = Matrix()

    var version = 0
        private set

    var bendDp = 34f
        private set
    var edgeDp = 14f
        private set
    var blurDp = 0.5f
        private set

    var dim = 0f
        set(value) {
            if (value != field) {
                field = value
                changed()
            }
        }

    private var sw = 0
    private var sh = 0
    private val listeners = ArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    fun setStyle(bend: Float, edge: Float, blur: Float) {
        bendDp = bend
        edgeDp = edge
        blurDp = blur
        changed()
    }

    fun setBitmap(b: Bitmap) {
        bitmap = b
        small = Bitmap.createScaledBitmap(b, max(1, b.width / 10), max(1, b.height / 10), true)
        rebuild()
    }

    fun setScreen(w: Int, h: Int) {
        if (w == sw && h == sh) return
        sw = w
        sh = h
        rebuild()
    }

    private fun fit(bw: Int, bh: Int, out: Matrix) {
        val s = max(sw.toFloat() / bw, sh.toFloat() / bh)
        out.setScale(s, s)
        out.postTranslate((sw - bw * s) / 2f, (sh - bh * s) / 2f)
    }

    private fun rebuild() {
        val b = bitmap ?: return
        val sm = small ?: return
        if (sw == 0 || sh == 0) return
        fit(b.width, b.height, matrix)
        fit(sm.width, sm.height, smallMatrix)
        shader = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).also {
            it.setLocalMatrix(matrix)
        }
        changed()
    }

    private fun changed() {
        version++
        for (l in ArrayList(listeners)) l()
    }
}
