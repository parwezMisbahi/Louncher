package com.hami.glasslauncher

import android.content.Context
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Bitmap
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import kotlin.math.min

/**
 * A container that draws a liquid-glass background (refracted wallpaper)
 * and then its children on top. cornerPx < 0 means a full pill / circle.
 */
class GlassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    var cornerPx: Float = -1f
        set(value) {
            field = value
            invalidateOutline()
            invalidate()
        }

    private val dp = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * dp
        color = 0x8CFFFFFF.toInt()
    }
    private val rect = RectF()
    private val loc = IntArray(2)
    private var lastX = Int.MIN_VALUE
    private var lastY = Int.MIN_VALUE
    private var lastVer = -1

    private var agsl: Any? = null
    private var agslFailed = false
    private var fbShader: BitmapShader? = null
    private var fbBitmap: Bitmap? = null
    private val fbMatrix = Matrix()

    private var vto: ViewTreeObserver? = null
    private val pre = ViewTreeObserver.OnPreDrawListener {
        getLocationInWindow(loc)
        if (loc[0] != lastX || loc[1] != lastY || Backdrop.version != lastVer) invalidate()
        true
    }

    init {
        setWillNotDraw(false)
        clipChildren = false
        clipToPadding = false
        elevation = 8f * dp
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius())
            }
        }
    }

    private fun radius(): Float {
        val half = min(width, height) / 2f
        return if (cornerPx < 0f) half else min(cornerPx, half)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        vto = viewTreeObserver
        vto?.addOnPreDrawListener(pre)
    }

    override fun onDetachedFromWindow() {
        vto?.let { if (it.isAlive) it.removeOnPreDrawListener(pre) }
        vto = null
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        invalidateOutline()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        getLocationInWindow(loc)
        lastX = loc[0]
        lastY = loc[1]
        lastVer = Backdrop.version

        val r = radius()
        // smaller tiles get a proportionally smaller lens
        val s = (min(w, h) / dp / 100f).coerceIn(0.45f, 1f)
        val bg = Backdrop.shader

        if (Build.VERSION.SDK_INT >= 33 && bg != null && !agslFailed) {
            try {
                val p = (agsl as? AgslPainter) ?: AgslPainter().also { agsl = it }
                p.draw(
                    canvas, bg, w, h, loc[0].toFloat(), loc[1].toFloat(), r,
                    Backdrop.edgeDp * dp * s, Backdrop.bendDp * dp * s,
                    Backdrop.blurDp * dp, Backdrop.dim, dp
                )
                return
            } catch (t: Throwable) {
                agslFailed = true
            }
        }
        drawFallback(canvas, w, h, r)
    }

    /** Android 9-12: blurred wallpaper + tint + rim, no refraction. */
    private fun drawFallback(canvas: Canvas, w: Float, h: Float, r: Float) {
        rect.set(0f, 0f, w, h)
        val sm = Backdrop.small
        if (sm != null) {
            var sh = fbShader
            if (sh == null || fbBitmap !== sm) {
                sh = BitmapShader(sm, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                fbShader = sh
                fbBitmap = sm
            }
            fbMatrix.set(Backdrop.smallMatrix)
            fbMatrix.postTranslate(-loc[0].toFloat(), -loc[1].toFloat())
            sh.setLocalMatrix(fbMatrix)
            paint.shader = sh
            paint.color = Color.WHITE
            canvas.drawRoundRect(rect, r, r, paint)
        }
        paint.shader = null
        if (Backdrop.dim > 0f) {
            paint.color = Color.argb((Backdrop.dim * 255).toInt(), 0, 0, 0)
            canvas.drawRoundRect(rect, r, r, paint)
        }
        paint.color = 0x2AFFFFFF
        canvas.drawRoundRect(rect, r, r, paint)
        val inset = ring.strokeWidth / 2f
        rect.set(inset, inset, w - inset, h - inset)
        canvas.drawRoundRect(rect, r - inset, r - inset, ring)
    }
}
