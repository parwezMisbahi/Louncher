package com.hami.glasslauncher

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RuntimeShader
import android.graphics.Shader
import androidx.annotation.RequiresApi

/**
 * Liquid-glass lens as an AGSL shader (Android 13+).
 * Port of the SVG feDisplacementMap setup from liquid-glass-lens.html:
 *  - rounded-rect SDF -> edge normal -> displacement only near the rim
 *  - R / G / B bent by 1.0 / 0.93 / 0.86 (water-like colour fringe)
 *  - saturate(1.5), small blur, rim light + top/bottom glow
 */
@RequiresApi(33)
class AgslPainter {
    private val shader = RuntimeShader(SRC)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun draw(
        canvas: Canvas, bg: Shader, w: Float, h: Float,
        ox: Float, oy: Float, radius: Float, edge: Float,
        bend: Float, blur: Float, dim: Float, dpx: Float
    ) {
        shader.setInputShader("bg", bg)
        shader.setFloatUniform("size", w, h)
        shader.setFloatUniform("origin", ox, oy)
        shader.setFloatUniform("radius", radius)
        shader.setFloatUniform("edge", edge)
        shader.setFloatUniform("bend", bend)
        shader.setFloatUniform("blur", blur)
        shader.setFloatUniform("dim", dim)
        shader.setFloatUniform("dpx", dpx)
        paint.shader = shader
        canvas.drawRect(0f, 0f, w, h, paint)
    }

    companion object {
        private const val SRC = """
uniform shader bg;
uniform float2 size;
uniform float2 origin;
uniform float radius;
uniform float edge;
uniform float bend;
uniform float blur;
uniform float dim;
uniform float dpx;

float3 blurAt(float2 p) {
    float3 c = float3(bg.eval(p).rgb);
    if (blur < 0.5) { return c; }
    float k = blur * 0.7071;
    c += float3(bg.eval(p + float2( k,  k)).rgb);
    c += float3(bg.eval(p + float2(-k,  k)).rgb);
    c += float3(bg.eval(p + float2( k, -k)).rgb);
    c += float3(bg.eval(p + float2(-k, -k)).rgb);
    return c / 5.0;
}

half4 main(float2 fc) {
    float2 hs = size * 0.5;
    float2 p = fc - hs;
    float r = min(radius, min(hs.x, hs.y));
    float2 q = abs(p) - (hs - float2(r));
    float sdf = length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;
    float depth = -sdf;
    float a = clamp(depth + 0.5, 0.0, 1.0);
    if (a <= 0.0) { return half4(0.0); }

    float2 n;
    if (q.x > 0.0 && q.y > 0.0) {
        n = sign(p) * q / max(length(q), 0.0001);
    } else if (q.x > q.y) {
        n = float2(sign(p.x), 0.0);
    } else {
        n = float2(0.0, sign(p.y));
    }

    float t = clamp(1.0 - depth / max(edge, 0.5), 0.0, 1.0);
    float m = t * t * (3.0 - 2.0 * t);
    float2 d = -n * m * bend;
    float2 base = fc + origin;

    float3 col;
    col.r = blurAt(base + d).r;
    col.g = blurAt(base + d * 0.93).g;
    col.b = blurAt(base + d * 0.86).b;

    float l = dot(col, float3(0.299, 0.587, 0.114));
    col = mix(float3(l), col, 1.5);
    col *= (1.0 - dim);
    col = mix(col, float3(1.0), 0.06);

    float rim = 1.0 - smoothstep(0.0, 1.5 * dpx, depth);
    float top = max(0.0, -n.y) * (1.0 - smoothstep(0.0, 8.0 * dpx, depth));
    float bot = max(0.0, n.y) * (1.0 - smoothstep(0.0, 10.0 * dpx, depth));
    col += float3(1.0) * (rim * 0.55 + top * 0.45);
    col += float3(1.0, 0.78, 0.86) * (bot * 0.40);
    col = clamp(col, 0.0, 1.0);

    return half4(half3(col * a), half(a));
}
"""
    }
}
