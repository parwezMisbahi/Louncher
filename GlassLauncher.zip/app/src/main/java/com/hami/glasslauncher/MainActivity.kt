package com.hami.glasslauncher

import android.annotation.SuppressLint
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

data class AppEntry(val label: String, val component: ComponentName, val icon: Drawable)

class AppVH(
    val box: LinearLayout,
    val glass: GlassView,
    val icon: ImageView,
    val label: TextView
) : RecyclerView.ViewHolder(box)

class MainActivity : ComponentActivity() {

    private val density: Float get() = resources.displayMetrics.density
    private fun px(v: Int) = (v * density).toInt()

    private val prefs by lazy { getSharedPreferences("glass", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var homeGroup: FrameLayout
    private lateinit var pinned: FrameLayout
    private lateinit var homeUi: FrameLayout
    private lateinit var drawer: FrameLayout
    private lateinit var recycler: RecyclerView
    private lateinit var search: EditText
    private lateinit var clockTime: TextView
    private lateinit var clockDate: TextView
    private lateinit var adapter: AppAdapter
    private var drawerOpen = false

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadPickedWallpaper(uri)
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 15_000)
        }
    }

    // swipe down on the drawer (when list is at the top) closes it
    private val drawerGestures by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (drawerOpen && vy > 1800f && !recycler.canScrollVertically(-1)) {
                    closeDrawer()
                    return true
                }
                return false
            }
        })
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val ctl = WindowCompat.getInsetsController(window, window.decorView)
        ctl.isAppearanceLightStatusBars = false
        ctl.isAppearanceLightNavigationBars = false

        loadStyle()
        buildUi()
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerOpen) closeDrawer()
            }
        })
        // HOME pressed while we are already open -> close the drawer
        addOnNewIntentListener { intent ->
            if (intent.action == Intent.ACTION_MAIN) closeDrawer()
        }

        loadWallpaperAsync()
        loadApps()
        loadPins()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (drawerOpen) drawerGestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- UI

    private fun match() = FrameLayout.LayoutParams(MATCH, MATCH)

    private fun buildUi() {
        root = FrameLayout(this)
        root.addView(BackgroundView(this), match())

        homeGroup = FrameLayout(this)
        val gestureLayer = View(this)
        homeGroup.addView(gestureLayer, match())
        setupHomeGestures(gestureLayer)

        pinned = FrameLayout(this)
        homeGroup.addView(pinned, match())

        homeUi = FrameLayout(this)
        homeGroup.addView(homeUi, match())
        buildHomeUi()
        root.addView(homeGroup, match())

        buildDrawer()
        root.addView(drawer, match())

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            homeUi.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            drawer.setPadding(bars.left, bars.top, bars.right, 0)
            recycler.setPadding(px(8), px(8), px(8), px(24) + max(bars.bottom, ime.bottom))
            insets
        }
    }

    private fun buildHomeUi() {
        // clock
        val clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        clockTime = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 72f
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            includeFontPadding = false
            setShadowLayer(14f, 0f, 3f, 0x66000000)
        }
        clockDate = TextView(this).apply {
            setTextColor(0xE6FFFFFF.toInt())
            textSize = 17f
            setShadowLayer(10f, 0f, 2f, 0x66000000)
        }
        clockBox.addView(clockTime)
        clockBox.addView(clockDate)
        homeUi.addView(
            clockBox,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = px(28) }
        )
        updateClock()

        // search pill
        val pill = GlassView(this)
        val pillText = TextView(this).apply {
            text = "Search apps"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 2f, 0x66000000)
        }
        pill.addView(pillText, FrameLayout.LayoutParams(MATCH, MATCH))
        pill.setOnClickListener { openDrawer(true) }
        homeUi.addView(
            pill,
            FrameLayout.LayoutParams(px(230), px(52), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = px(14 + 88 + 14) }
        )

        // dock
        val dock = GlassView(this).apply { cornerPx = px(34).toFloat() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for ((intent, icon) in dockApps()) {
            val iv = ImageView(this).apply {
                setImageDrawable(icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(px(14), px(14), px(14), px(14))
            }
            iv.setOnClickListener { launch(intent, iv) }
            row.addView(iv, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        dock.addView(row, match())
        homeUi.addView(
            dock,
            FrameLayout.LayoutParams(MATCH, px(88), Gravity.BOTTOM).apply {
                leftMargin = px(16)
                rightMargin = px(16)
                bottomMargin = px(14)
            }
        )
    }

    private fun dockApps(): List<Pair<Intent, Drawable>> {
        val pm = packageManager
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        return probes.mapNotNull { probe ->
            var ri: ResolveInfo? = pm.resolveActivity(probe, 0)
            if (ri == null || ri.activityInfo.packageName == "android") {
                ri = pm.queryIntentActivities(probe, 0)
                    .firstOrNull { it.activityInfo.packageName != "android" }
            }
            if (ri == null) {
                null
            } else {
                val launchIntent = Intent(probe)
                    .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                Pair(launchIntent, ri.loadIcon(pm))
            }
        }
    }

    private fun updateClock() {
        val now = Date()
        val is24 = android.text.format.DateFormat.is24HourFormat(this)
        clockTime.text = SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault()).format(now)
        val pattern = android.text.format.DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM")
        clockDate.text = SimpleDateFormat(pattern, Locale.getDefault()).format(now)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupHomeGestures(v: View) {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 != null && e1.y - e2.y > px(90) && !drawerOpen) openDrawer(false)
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -900f && !drawerOpen) openDrawer(false)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                showHomeMenu()
            }
        })
        v.setOnTouchListener { _, e -> gd.onTouchEvent(e) }
    }

    private fun showHomeMenu() {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Change wallpaper", "Glass settings")) { _, which ->
                if (which == 0) pickImage.launch("image/*") else showGlassSettings()
            }
            .show()
    }

    private fun showGlassSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(12), px(20), px(4))
        }
        var b = Backdrop.bendDp
        var e = Backdrop.edgeDp
        var bl = Backdrop.blurDp

        fun row(name: String, maxVal: Int, init: Int, label: (Int) -> String, onChange: (Int) -> Unit) {
            val tv = TextView(this).apply { text = "$name: ${label(init)}" }
            val sb = SeekBar(this).apply {
                max = maxVal
                progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        tv.text = "$name: ${label(p)}"
                        onChange(p)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            box.addView(tv)
            box.addView(sb)
        }

        row("Bend", 80, b.toInt(), { "$it" }) { b = it.toFloat(); Backdrop.setStyle(b, e, bl) }
        row("Edge", 38, (e - 2f).toInt(), { "${it + 2}" }) { e = it + 2f; Backdrop.setStyle(b, e, bl) }
        row("Blur", 16, (bl * 2f).toInt(), { "${it / 2f}" }) { bl = it / 2f; Backdrop.setStyle(b, e, bl) }

        AlertDialog.Builder(this)
            .setTitle("Glass settings")
            .setView(box)
            .setPositiveButton("OK", null)
            .setOnDismissListener { saveStyle() }
            .show()
    }

    private fun loadStyle() {
        Backdrop.setStyle(
            prefs.getFloat("bend", 34f),
            prefs.getFloat("edge", 14f),
            prefs.getFloat("blur", 0.5f)
        )
    }

    private fun saveStyle() {
        prefs.edit()
            .putFloat("bend", Backdrop.bendDp)
            .putFloat("edge", Backdrop.edgeDp)
            .putFloat("blur", Backdrop.blurDp)
            .apply()
    }

    // ---------------------------------------------------------------- drawer

    private fun buildDrawer() {
        drawer = FrameLayout(this).apply {
            isClickable = true
            visibility = View.GONE
        }
        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            background = null
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            textSize = 17f
            setPadding(px(22), 0, px(22), 0)
        }
        val searchGlass = GlassView(this)
        searchGlass.addView(search, FrameLayout.LayoutParams(MATCH, MATCH))

        adapter = AppAdapter()
        recycler = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        recycler.adapter = adapter

        drawer.addView(
            searchGlass,
            FrameLayout.LayoutParams(MATCH, px(52)).apply {
                topMargin = px(16)
                leftMargin = px(20)
                rightMargin = px(20)
            }
        )
        drawer.addView(
            recycler,
            FrameLayout.LayoutParams(MATCH, MATCH).apply { topMargin = px(16 + 52 + 12) }
        )

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                adapter.filter(s?.toString() ?: "")
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            adapter.firstShown()?.let { launchApp(it, null) }
            true
        }
    }

    private fun openDrawer(focusSearch: Boolean) {
        if (drawerOpen) return
        drawerOpen = true
        val h = root.height.toFloat()
        drawer.visibility = View.VISIBLE
        drawer.translationY = h
        drawer.animate()
            .translationY(0f)
            .setDuration(320)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .setUpdateListener { Backdrop.dim = 0.42f * (1f - drawer.translationY / h) }
            .withEndAction {
                if (focusSearch) {
                    search.requestFocus()
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, 0)
                }
            }
            .start()
        homeGroup.animate().alpha(0f).setDuration(240).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        search.setText("")
        search.clearFocus()
        val h = root.height.toFloat()
        homeGroup.animate().alpha(1f).setDuration(260).start()
        drawer.animate()
            .translationY(h)
            .setDuration(260)
            .setInterpolator(AccelerateInterpolator(1.4f))
            .setUpdateListener { Backdrop.dim = 0.42f * (1f - drawer.translationY / h) }
            .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
            .start()
    }

    inner class AppAdapter : RecyclerView.Adapter<AppVH>() {
        private var all: List<AppEntry> = emptyList()
        private var shown: List<AppEntry> = emptyList()
        private var query = ""

        fun submit(list: List<AppEntry>) { all = list; applyFilter() }
        fun filter(q: String) { query = q.trim(); applyFilter() }
        fun firstShown(): AppEntry? = shown.firstOrNull()

        private fun applyFilter() {
            shown = if (query.isEmpty()) all else all.filter { it.label.contains(query, ignoreCase = true) }
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppVH {
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, px(10), 0, px(10))
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            }
            val glass = GlassView(this@MainActivity).apply { cornerPx = px(20).toFloat() }
            val icon = ImageView(this@MainActivity)
            glass.addView(icon, FrameLayout.LayoutParams(px(42), px(42), Gravity.CENTER))
            box.addView(glass, LinearLayout.LayoutParams(px(66), px(66)))
            val label = TextView(this@MainActivity).apply {
                setTextColor(Color.WHITE)
                textSize = 11f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setShadowLayer(6f, 0f, 2f, 0x99000000.toInt())
            }
            box.addView(label, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(6) })
            return AppVH(box, glass, icon, label)
        }

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(holder: AppVH, position: Int) {
            val e = shown[position]
            holder.icon.setImageDrawable(e.icon)
            holder.label.text = e.label
            holder.box.setOnClickListener { launchApp(e, holder.glass) }
            holder.box.setOnLongClickListener { appMenu(e); true }
        }
    }

    private fun appMenu(e: AppEntry) {
        AlertDialog.Builder(this)
            .setTitle(e.label)
            .setItems(arrayOf("Pin to home", "App info", "Uninstall")) { _, which ->
                when (which) {
                    0 -> pinApp(e.component)
                    1 -> openAppInfo(e.component.packageName)
                    2 -> try {
                        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.component.packageName}")))
                    } catch (_: Exception) {
                    }
                }
            }
            .show()
    }

    private fun openAppInfo(pkg: String) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        } catch (_: Exception) {
        }
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val probe = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(probe, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppEntry(
                        it.loadLabel(pm).toString(),
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                        it.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { adapter.submit(list) }
        }.start()
    }

    // ---------------------------------------------------------------- launching

    private fun launch(intent: Intent, from: View?) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val opts = if (from != null) {
                ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height).toBundle()
            } else null
            startActivity(intent, opts)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchComponent(cn: ComponentName, from: View?) {
        launch(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(cn)
                .addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
            from
        )
    }

    private fun launchApp(e: AppEntry, from: View?) = launchComponent(e.component, from)

    // ---------------------------------------------------------------- pinned tiles on home

    private fun loadPins() {
        val set = prefs.getStringSet("pins", emptySet()) ?: emptySet()
        for (s in set) {
            val p = s.split("|")
            if (p.size < 3) continue
            val cn = ComponentName.unflattenFromString(p[0]) ?: continue
            addPinView(cn, p[1].toFloatOrNull() ?: 0.1f, p[2].toFloatOrNull() ?: 0.2f, false)
        }
    }

    private fun savePins() {
        val out = HashSet<String>()
        for (i in 0 until pinned.childCount) {
            val t = pinned.getChildAt(i)
            val cn = t.tag as? ComponentName ?: continue
            val xf = t.x / max(1f, (pinned.width - t.width).toFloat())
            val yf = t.y / max(1f, (pinned.height - t.height).toFloat())
            out.add("${cn.flattenToString()}|$xf|$yf")
        }
        prefs.edit().putStringSet("pins", out).apply()
    }

    private fun pinApp(cn: ComponentName) {
        for (i in 0 until pinned.childCount) {
            if (pinned.getChildAt(i).tag == cn) {
                Toast.makeText(this, "Already on home", Toast.LENGTH_SHORT).show()
                return
            }
        }
        val n = pinned.childCount
        addPinView(cn, 0.12f + 0.3f * (n % 3), 0.2f + 0.13f * ((n / 3) % 5), true)
        closeDrawer()
    }

    private fun addPinView(cn: ComponentName, xf: Float, yf: Float, save: Boolean) {
        val pm = packageManager
        val info = try { pm.getActivityInfo(cn, 0) } catch (e: Exception) { return }
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            tag = cn
        }
        val glass = GlassView(this).apply { cornerPx = px(20).toFloat() }
        val iv = ImageView(this).apply { setImageDrawable(info.loadIcon(pm)) }
        glass.addView(iv, FrameLayout.LayoutParams(px(42), px(42), Gravity.CENTER))
        tile.addView(glass, LinearLayout.LayoutParams(px(66), px(66)))
        val tv = TextView(this).apply {
            text = info.loadLabel(pm).toString()
            setTextColor(Color.WHITE)
            textSize = 11f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 2f, 0x99000000.toInt())
        }
        tile.addView(tv, LinearLayout.LayoutParams(px(76), WRAP).apply { topMargin = px(4) })
        pinned.addView(tile, FrameLayout.LayoutParams(WRAP, WRAP))

        tile.doOnLayout {
            tile.x = xf.coerceIn(0f, 1f) * max(0, pinned.width - tile.width)
            tile.y = yf.coerceIn(0f, 1f) * max(0, pinned.height - tile.height)
            if (save) savePins()
        }

        makeDraggable(
            tile,
            onClick = { launchComponent(cn, glass) },
            onLong = {
                AlertDialog.Builder(this)
                    .setItems(arrayOf("Remove from home", "App info")) { _, which ->
                        if (which == 0) {
                            pinned.removeView(tile)
                            savePins()
                        } else openAppInfo(cn.packageName)
                    }
                    .show()
            },
            onDrop = { savePins() }
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(v: View, onClick: () -> Unit, onLong: () -> Unit, onDrop: () -> Unit) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        var dragging = false
        var longFired = false
        val longRun = Runnable {
            if (!dragging) {
                longFired = true
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onLong()
            }
        }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = v.x
                    startY = v.y
                    dragging = false
                    longFired = false
                    v.postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && !longFired && hypot(dx, dy) > slop) {
                        dragging = true
                        v.removeCallbacks(longRun)
                        v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
                    }
                    if (dragging) {
                        val maxX = (pinned.width - v.width).toFloat().coerceAtLeast(0f)
                        val maxY = (pinned.height - v.height).toFloat().coerceAtLeast(0f)
                        v.x = (startX + dx).coerceIn(0f, maxX)
                        v.y = (startY + dy).coerceIn(0f, maxY)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.removeCallbacks(longRun)
                    if (dragging) {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        onDrop()
                    } else if (!longFired && e.actionMasked == MotionEvent.ACTION_UP) {
                        onClick()
                    }
                }
            }
            true
        }
    }

    // ---------------------------------------------------------------- wallpaper

    private fun loadWallpaperAsync() {
        Thread {
            val bmp = loadSavedWallpaper() ?: loadSystemWallpaper() ?: defaultBitmap()
            runOnUiThread { Backdrop.setBitmap(bmp) }
        }.start()
    }

    private fun loadSavedWallpaper(): Bitmap? {
        return try {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) BitmapFactory.decodeFile(f.path) else null
        } catch (t: Throwable) {
            null
        }
    }

    private fun loadSystemWallpaper(): Bitmap? {
        return try {
            val d = WallpaperManager.getInstance(this).drawable ?: return null
            val iw = d.intrinsicWidth
            val ih = d.intrinsicHeight
            if (iw <= 0 || ih <= 0) return null
            val sc = min(1f, 2400f / max(iw, ih))
            d.toBitmap(max(1, (iw * sc).toInt()), max(1, (ih * sc).toInt()), Bitmap.Config.ARGB_8888)
        } catch (t: Throwable) {
            null
        }
    }

    private fun defaultBitmap(): Bitmap {
        val w = 1080
        val h = 2400
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(0xFFFF3D6E.toInt(), 0xFF2A8CFF.toInt(), 0xFFFFD23F.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = null
        p.color = Color.WHITE
        p.strokeWidth = 5f
        var y = 0
        while (y <= h) {
            p.alpha = if (y % 420 == 0) 210 else 70
            c.drawLine(0f, y.toFloat(), w.toFloat(), y.toFloat(), p)
            y += 140
        }
        var x = 0
        while (x <= w) {
            p.alpha = if (x % 420 == 0) 210 else 70
            c.drawLine(x.toFloat(), 0f, x.toFloat(), h.toFloat(), p)
            x += 140
        }
        return bmp
    }

    private fun loadPickedWallpaper(uri: Uri) {
        Thread {
            try {
                val src = ImageDecoder.createSource(contentResolver, uri)
                val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val longSide = max(info.size.width, info.size.height)
                    if (longSide > 2400) {
                        val s = 2400f / longSide
                        decoder.setTargetSize(
                            max(1, (info.size.width * s).toInt()),
                            max(1, (info.size.height * s).toInt())
                        )
                    }
                }
                FileOutputStream(File(filesDir, "wallpaper.jpg")).use {
                    bmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
                }
                runOnUiThread { Backdrop.setBitmap(bmp) }
            } catch (t: Throwable) {
                runOnUiThread {
                    Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
