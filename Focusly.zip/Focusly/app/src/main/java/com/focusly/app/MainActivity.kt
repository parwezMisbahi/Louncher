package com.focusly.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

val resumeTick = mutableIntStateOf(0)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { App() }
    }
    override fun onResume() { super.onResume(); resumeTick.intValue++ }
}

val DL = "SMTWTFS"
fun hm(m: Int) = "%02d:%02d".format(m / 60 % 24, m % 60)
fun newId() = (System.currentTimeMillis() % 100000).toInt() + 1
fun daysText(d: Set<Int>, none: String) = if (d.isEmpty()) none else if (d.size == 7) "Roz" else d.sorted().joinToString(" ") { DL[it - 1].toString() }
val dim = Color.White.copy(alpha = .7f)

@Composable fun Glass(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = .08f))
        .border(1.dp, Color.White.copy(alpha = .15f), RoundedCornerShape(20.dp)).padding(16.dp), content = content)

@Composable fun DaysRow(sel: Set<Int>, on: (Set<Int>) -> Unit) = Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
    for (d in 1..7) {
        val s = d in sel
        Box(Modifier.size(32.dp).clip(CircleShape).background(if (s) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = .12f))
            .clickable { on(if (s) sel - d else sel + d) }, Alignment.Center) {
            Text(DL[d - 1].toString(), color = if (s) Color.Black else Color.White, fontSize = 13.sp)
        }
    }
}

@Composable fun Page(title: String, onAdd: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) = Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(top = 48.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, fontSize = 30.sp, color = Color.White, fontWeight = FontWeight.Bold)
        content()
    }
    if (onAdd != null) FloatingActionButton(onClick = onAdd, Modifier.align(Alignment.BottomEnd).padding(20.dp)) { Icon(Icons.Default.Add, null) }
}

@Composable fun App() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8AB4FF))) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0F1226), Color(0xFF1B1F3B))))) {
            Scaffold(containerColor = Color.Transparent, bottomBar = {
                NavigationBar(containerColor = Color.White.copy(alpha = .06f)) {
                    listOf("⏰" to "Alarm", "🔔" to "Remind", "⛔" to "Block", "🎯" to "Goals", "🔒" to "Lock").forEachIndexed { i, t ->
                        NavigationBarItem(tab == i, { tab = i }, { Text(t.first, fontSize = 20.sp) }, label = { Text(t.second) })
                    }
                }
            }) { pad -> Box(Modifier.padding(pad)) { when (tab) { 0 -> AlarmsTab(); 1 -> RemindersTab(); 2 -> BlockTab(); 3 -> GoalsTab(); else -> LockTab() } } }
        }
    }
}

@Composable fun AlarmsTab() {
    val c = LocalContext.current
    val list = remember { mutableStateListOf<Alarm>().apply { addAll(Store.alarms(c)) } }
    var add by remember { mutableStateOf(false) }
    fun save() = Store.saveAlarms(c, list.toList())
    Page("Alarms", { add = true }) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { a ->
                Glass { Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(hm(a.hour * 60 + a.minute), fontSize = 34.sp, color = Color.White)
                        Text("${a.label.ifEmpty { "Alarm" }} • ${daysText(a.days, "Ek baar")}", color = dim)
                    }
                    Switch(a.on, { v -> val n = a.copy(on = v); list[list.indexOf(a)] = n; save(); Sched.arm(c, n) })
                    IconButton({ Sched.cancel(c, "a", a.id); list.remove(a); save() }) { Icon(Icons.Default.Delete, null, tint = dim) }
                } }
            }
        }
    }
    if (add) {
        var h by remember { mutableIntStateOf(7) }; var m by remember { mutableIntStateOf(0) }
        var d by remember { mutableStateOf(setOf<Int>()) }; var l by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { add = false }, title = { Text("Naya alarm") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton({ TimePickerDialog(c, { _, hh, mm -> h = hh; m = mm }, h, m, false).show() }) { Text(hm(h * 60 + m), fontSize = 24.sp) }
                OutlinedTextField(l, { l = it }, label = { Text("Label") }, singleLine = true)
                DaysRow(d) { d = it }
            } },
            confirmButton = { TextButton({ val a = Alarm(newId(), h, m, d, l); list.add(a); save(); Sched.arm(c, a); add = false }) { Text("Save") } },
            dismissButton = { TextButton({ add = false }) { Text("Cancel") } })
    }
}

@Composable fun RemindersTab() {
    val c = LocalContext.current
    val list = remember { mutableStateListOf<Reminder>().apply { addAll(Store.reminders(c)) } }
    var add by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    fun save() = Store.saveReminders(c, list.toList())
    Page("Reminders", { add = true }) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { r ->
                Glass { Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.title, fontSize = 18.sp, color = Color.White)
                        Text(fmt.format(r.at) + if (r.daily) " • Roz" else "", color = dim)
                    }
                    Switch(r.on, { v ->
                        val n = r.copy(on = v); list[list.indexOf(r)] = n; save()
                        if (v && n.at > System.currentTimeMillis()) Sched.set(c, "r", n.id, n.at) else Sched.cancel(c, "r", n.id)
                    })
                    IconButton({ Sched.cancel(c, "r", r.id); list.remove(r); save() }) { Icon(Icons.Default.Delete, null, tint = dim) }
                } }
            }
        }
    }
    if (add) {
        var t by remember { mutableStateOf("") }
        var at by remember { mutableLongStateOf(System.currentTimeMillis() + 3600000L) }
        var daily by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest = { add = false }, title = { Text("Naya reminder") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(t, { t = it }, label = { Text("Kya yaad dilana hai?") })
                OutlinedButton({
                    val k = Calendar.getInstance().apply { timeInMillis = at }
                    DatePickerDialog(c, { _, y, mo, dd ->
                        TimePickerDialog(c, { _, hh, mm -> at = Calendar.getInstance().apply { set(y, mo, dd, hh, mm, 0) }.timeInMillis },
                            k[Calendar.HOUR_OF_DAY], k[Calendar.MINUTE], false).show()
                    }, k[Calendar.YEAR], k[Calendar.MONTH], k[Calendar.DAY_OF_MONTH]).show()
                }) { Text(fmt.format(at)) }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(daily, { daily = it }); Text("Roz repeat") }
            } },
            confirmButton = { TextButton({
                val r = Reminder(newId(), t.ifEmpty { "Reminder" }, at, daily); list.add(r); save()
                if (at > System.currentTimeMillis()) Sched.set(c, "r", r.id, at); add = false
            }) { Text("Save") } },
            dismissButton = { TextButton({ add = false }) { Text("Cancel") } })
    }
}

@Composable fun BlockTab() {
    val c = LocalContext.current
    val list = remember { mutableStateListOf<Rule>().apply { addAll(Store.rules(c)) } }
    var add by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf<Pair<String, String>?>(null) }
    val accOn = remember(resumeTick.intValue) { accessibilityOn(c) }
    val apps = remember {
        c.packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(c.packageManager).toString() }
            .distinctBy { it.first }.filter { it.first != c.packageName }.sortedBy { it.second.lowercase() }
    }
    fun save() = Store.saveRules(c, list.toList())
    Page("App Block", { add = true }) {
        if (!accOn) Glass {
            Text("Block chalane ke liye Accessibility permission on karein.", color = Color.White)
            Button({ c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Enable") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { r ->
                Glass { Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, fontSize = 18.sp, color = Color.White)
                        val w = if (r.start == 0 && r.end == 1440) "Poora din" else "${hm(r.start)} – ${hm(r.end)}"
                        Text("$w • ${daysText(r.days, "Roz")}", color = dim)
                    }
                    Switch(r.on, { v -> list[list.indexOf(r)] = r.copy(on = v); save() })
                    IconButton({ list.remove(r); save() }) { Icon(Icons.Default.Delete, null, tint = dim) }
                } }
            }
        }
    }
    if (add && pick == null) AlertDialog(onDismissRequest = { add = false }, title = { Text("App chunein") },
        text = { LazyColumn(Modifier.height(360.dp)) { items(listOf("*" to "🌐 Saare apps") + apps) { a -> Text(a.second, Modifier.fillMaxWidth().clickable { pick = a }.padding(vertical = 12.dp)) } } },
        confirmButton = { TextButton({ add = false }) { Text("Cancel") } })
    pick?.let { p ->
        var s by remember { mutableIntStateOf(22 * 60) }; var e by remember { mutableIntStateOf(7 * 60) }
        var all by remember { mutableStateOf(false) }; var d by remember { mutableStateOf(setOf<Int>()) }
        AlertDialog(onDismissRequest = { add = false; pick = null }, title = { Text(p.second) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(all, { all = it }); Text("Poora din") }
                if (!all) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ TimePickerDialog(c, { _, hh, mm -> s = hh * 60 + mm }, s / 60, s % 60, false).show() }) { Text("Start ${hm(s)}") }
                    OutlinedButton({ TimePickerDialog(c, { _, hh, mm -> e = hh * 60 + mm }, e / 60, e % 60, false).show() }) { Text("End ${hm(e)}") }
                }
                Text("Din (khali = roz)", color = dim, fontSize = 12.sp)
                DaysRow(d) { d = it }
            } },
            confirmButton = { TextButton({
                list.add(Rule(newId(), p.first, p.second, if (all) 0 else s, if (all) 1440 else e, d)); save(); add = false; pick = null
            }) { Text("Save") } },
            dismissButton = { TextButton({ add = false; pick = null }) { Text("Cancel") } })
    }
}
