package com.focusly.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

fun isActive(r: Rule): Boolean {
    val c = Calendar.getInstance()
    if (r.days.isNotEmpty() && c.get(Calendar.DAY_OF_WEEK) !in r.days) return false
    val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    return if (r.start <= r.end) now in r.start until r.end else now >= r.start || now < r.end
}

fun accessibilityOn(c: Context) =
    (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(c.packageName)

class BlockService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val hit = Store.rules(this).any { it.on && isActive(it) && (it.pkg == pkg || (it.pkg == "*" && !safe(pkg))) } ||
            (Lock.until(this) > System.currentTimeMillis() && !safe(pkg))
        if (hit) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            startActivity(Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
    private fun safe(p: String): Boolean {
        if (p == packageName || p == "com.android.systemui" || p.contains("incallui") || p.contains("emergency")) return true
        val home = packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        val dialer = getSystemService(TelecomManager::class.java)?.defaultDialerPackage
        val ime = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        return p == home || p == dialer || ime.startsWith("$p/")
    }
    override fun onInterrupt() {}
}

class BlockActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0F1226), Color(0xFF2A1B3D)))), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔒", fontSize = 64.sp)
                    Text("App blocked", fontSize = 26.sp, color = Color.White)
                    Text("Abhi focus time hai", color = Color.White.copy(alpha = .7f))
                    Spacer(Modifier.height(24.dp))
                    Button({ goHome() }) { Text("Home") }
                }
            }
        }
    }
    override fun onBackPressed() { goHome() }
    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
