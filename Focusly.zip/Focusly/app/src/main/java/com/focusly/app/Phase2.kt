package com.focusly.app

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Locale

object Lock {
    fun until(c: Context) = c.getSharedPreferences("focusly", 0).getLong("lock", 0)
    fun set(c: Context, t: Long) = c.getSharedPreferences("focusly", 0).edit().putLong("lock", t).apply()
}

data class Goal(val id: Int, val name: String, val unit: String, val target: Int, val step: Int,
                val progress: Int, val day: Long, val streak: Int, val lastDone: Long)

object GoalStore {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun load(c: Context): List<Goal> {
        val a = JSONArray(sp(c).getString("goals", "[]")); val today = LocalDate.now().toEpochDay()
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val g = Goal(o.getInt("id"), o.getString("n"), o.getString("u"), o.getInt("t"), o.getInt("s"), o.getInt("p"), o.getLong("d"), o.getInt("k"), o.getLong("l"))
            if (g.day != today) g.copy(progress = 0, day = today) else g
        }
    }
    fun save(c: Context, l: List<Goal>) = sp(c).edit().putString("goals", JSONArray(l.map {
        JSONObject().put("id", it.id).put("n", it.name).put("u", it.unit).put("t", it.target).put("s", it.step)
            .put("p", it.progress).put("d", it.day).put("k", it.streak).put("l", it.lastDone)
    }).toString()).apply()

    fun bump(g: Goal, delta: Int): Goal {
        val today = LocalDate.now().toEpochDay()
        var n = g.copy(progress = (g.progress + delta).coerceAtLeast(0))
        if (g.progress < g.target && n.progress >= g.target)
            n = n.copy(streak = if (g.lastDone == today - 1) g.streak + 1 else 1, lastDone = today)
        if (g.progress >= g.target && n.progress < g.target && g.lastDone == today)
            n = n.copy(streak = (g.streak - 1).coerceAtLeast(0), lastDone = if (g.streak > 1) today - 1 else 0)
        return n
    }
}

@Composable fun GoalsTab() {
    val c = LocalContext.current
    val list = remember { mutableStateListOf<Goal>().apply { addAll(GoalStore.load(c)) } }
    var add by remember { mutableStateOf(false) }
    val today = LocalDate.now().toEpochDay()
    fun save() = GoalStore.save(c, list.toList())
    Page("Goals", { add = true }) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { g ->
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(g.name, fontSize = 18.sp, color = Color.White)
                            Text("${g.progress} / ${g.target} ${g.unit}", color = dim)
                        }
                        IconButton({ list.remove(g); save() }) { Icon(Icons.Default.Delete, null, tint = dim) }
                    }
                    LinearProgressIndicator({ (g.progress.toFloat() / g.target).coerceIn(0f, 1f) }, Modifier.fillMaxWidth().padding(vertical = 10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton({ list[list.indexOf(g)] = GoalStore.bump(g, -g.step); save() }) { Text("−") }
                        Button({ list[list.indexOf(g)] = GoalStore.bump(g, g.step); save() }) { Text("+${g.step}") }
                        Spacer(Modifier.weight(1f))
                        val st = if (g.lastDone >= today - 1) g.streak else 0
                        Text(if (g.progress >= g.target) "✅ Done  🔥$st" else "🔥 $st", color = Color.White)
                    }
                }
            }
        }
    }
    if (add) {
        var n by remember { mutableStateOf("") }; var u by remember { mutableStateOf("") }
        var t by remember { mutableStateOf("") }; var s by remember { mutableStateOf("1") }
        AlertDialog(onDismissRequest = { add = false }, title = { Text("Naya goal") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row {
                    TextButton({ n = "Paani peena"; u = "glass"; t = "8"; s = "1" }) { Text("💧 Paani") }
                    TextButton({ n = "Books padhna"; u = "pages"; t = "30"; s = "10" }) { Text("📚 Books") }
                }
                OutlinedTextField(n, { n = it }, label = { Text("Goal") }, singleLine = true)
                OutlinedTextField(u, { u = it }, label = { Text("Unit (glass, pages...)") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(t, { t = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("Roz target") }, singleLine = true)
                    OutlinedTextField(s, { s = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("Ek baar +") }, singleLine = true)
                }
            } },
            confirmButton = { TextButton({
                val tg = t.toIntOrNull() ?: 0
                if (n.isNotBlank() && tg > 0) {
                    list.add(Goal(newId(), n, u, tg, (s.toIntOrNull() ?: 1).coerceAtLeast(1), 0, today, 0, 0)); save(); add = false
                }
            }) { Text("Save") } },
            dismissButton = { TextButton({ add = false }) { Text("Cancel") } })
    }
}

@Composable fun LockTab() {
    val c = LocalContext.current
    var until by remember { mutableLongStateOf(Lock.until(c)) }
    var ask by remember { mutableIntStateOf(0) }
    val locked = until > System.currentTimeMillis()
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Page("Phone Lock", null) {
        Glass {
            if (locked) {
                Text("🔒 Phone locked", fontSize = 22.sp, color = Color.White)
                Text("${fmt.format(until)} tak sirf Phone, Home aur Focusly chalenge.", color = dim)
            } else {
                Text("Kitni der ke liye lock karna hai?", color = Color.White)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 60, 120).forEach { m -> OutlinedButton({ ask = m }) { Text(if (m < 60) "${m}m" else "${m / 60}h") } }
                }
            }
        }
        Glass { Text("Schedule wala lock: App Block mein \"🌐 Saare apps\" chuno aur time/din set karo.", color = dim) }
    }
    if (ask > 0) AlertDialog(onDismissRequest = { ask = 0 }, title = { Text("$ask minute lock?") },
        text = { Text("Beech mein hata nahi payenge.") },
        confirmButton = { TextButton({ until = System.currentTimeMillis() + ask * 60000L; Lock.set(c, until); ask = 0 }) { Text("Lock karo") } },
        dismissButton = { TextButton({ ask = 0 }) { Text("Cancel") } })
}
