package com.focusly.app

import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Notification-bar button. ON = Focusly may use location (and the phone's Location is switched on / opened).
 * OFF = Focusly may not use location: all location rules stay blocked until it is ON again.
 */
class LocTile : TileService() {
    override fun onStartListening() { refresh() }

    override fun onClick() {
        val c = applicationContext
        if (Presence.locAllowed(c)) {
            Presence.setLocAllowed(c, false)
        } else {
            Presence.setLocAllowed(c, true)
            val lm = c.getSystemService(LocationManager::class.java)
            val sysOn = try { lm.isLocationEnabled } catch (_: Throwable) { true }
            if (!Presence.hasFine(c)) open(Intent(c, MainActivity::class.java))
            else if (!sysOn) {
                var done = false
                if (c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
                    done = try { Settings.Secure.putInt(c.contentResolver, "location_mode", 3); true } catch (_: Throwable) { false }
                }
                if (!done) open(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            }
        }
        refresh()
    }

    private fun open(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 21, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            else @Suppress("DEPRECATION") startActivityAndCollapse(i)
        } catch (_: Throwable) {}
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = Presence.locAllowed(this)
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Focusly location"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "Allow" else "Not allowed"
        t.updateTile()
    }
}
