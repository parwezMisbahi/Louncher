package com.focusly.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Calendar

/** A saved place. [r] = radius in metres that counts as "reached". */
data class Place(val id: Int, val name: String, val lat: Double, val lng: Double, val r: Int)

object Places {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun all(c: Context): List<Place> = try {
        val a = JSONArray(sp(c).getString("places", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Place(o.getInt("id"), o.getString("n"), o.getDouble("lat"), o.getDouble("lng"), o.optInt("r", 150))
        }
    } catch (_: Throwable) { emptyList() }
    fun save(c: Context, l: List<Place>) = sp(c).edit().putString("places", JSONArray(l.map {
        JSONObject().put("id", it.id).put("n", it.name).put("lat", it.lat).put("lng", it.lng).put("r", it.r)
    }).toString()).apply()
    fun get(c: Context, id: Int): Place? = all(c).find { it.id == id }
}

/**
 * A place linked to a rule. m = 'b': block only here, 'u': unblock only here (blocked everywhere else),
 * 'r': release - a running block ends as soon as you reach this place.
 */
data class PlaceRef(val id: Int, val m: Char) {
    val block get() = m == 'b'
    val free get() = m == 'u'
    val rel get() = m == 'r'
}

/**
 * Location-linked rules. Everything happens inside the rule's time window:
 *  - 'b' places: the rule blocks ONLY while the phone is inside one of them.
 *  - 'u' places: the rule blocks everywhere EXCEPT inside one of them (live: leave it and the block is back).
 *  - 'r' places: the rule blocks until the phone reaches one of them (or the window ends); then it is done for that window.
 * Priority: inside a 'u' place or reaching an 'r' place always wins over a 'b' place.
 */
object Presence {
    private fun sp(c: Context) = c.getSharedPreferences("focusly_pres", 0)

    /** Identifies the current occurrence of the rule's window (so state resets for the next day's window). */
    fun occKey(r: Rule): Long {
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        var day = LocalDate.now().toEpochDay()
        if (r.start > r.end && now < r.end) day -= 1
        return day * 1440L + r.start
    }

    fun hasBlock(r: Rule) = r.pls.any { it.block }
    fun hasFree(r: Rule) = r.pls.any { it.free }
    fun hasRel(r: Rule) = r.pls.any { it.rel }
    /** Rules whose blocking follows the live position (not just a one-time release). */
    fun live(r: Rule) = hasBlock(r) || hasFree(r)

    /** "b" = inside a Block place, "u" = inside an Unblock place, "o" = neither / unknown. */
    private fun state(c: Context, r: Rule): String {
        val a = (sp(c).getString("in${r.id}", "") ?: "").split("|")
        return if (a.size == 2 && a[0].toLongOrNull() == occKey(r)) a[1] else "o"
    }
    private fun setState(c: Context, r: Rule, st: String) { sp(c).edit().putString("in${r.id}", "${occKey(r)}|$st").apply() }
    private fun reached(c: Context, r: Rule) = sp(c).getLong("r${r.id}", -1L) == occKey(r)
    private fun markReached(c: Context, r: Rule) { sp(c).edit().putLong("r${r.id}", occKey(r)).apply() }

    /** True = the location says "do not block this rule right now". */
    fun done(c: Context, r: Rule): Boolean {
        if (r.pls.isEmpty() || r.lim != 0) return false
        if (hasRel(r) && reached(c, r)) return true
        val st = state(c, r)
        if (st == "u") return true // inside an Unblock place: always wins
        return hasBlock(r) && st != "b" // Block places: blocks only while inside one
    }

    /** Short status for the UI: "wait", "reached", "in" (inside Block place), "free" (inside Unblock place), "out". */
    fun status(c: Context, r: Rule): String {
        if (r.pls.isEmpty() || r.lim != 0) return ""
        if (hasRel(r) && reached(c, r)) return "reached"
        val st = state(c, r)
        if (st == "u") return "free"
        if (hasBlock(r)) return if (st == "b") "in" else "out"
        return "wait"
    }

    /** Text shown on the block screen. */
    fun why(c: Context, r: Rule): String {
        val first = { m: Char -> r.pls.firstOrNull { it.m == m }?.let { Places.get(c, it.id)?.name } ?: "us jagah" }
        return when {
            hasBlock(r) -> "Is jagah par yah app block hai"
            hasFree(r) -> "Yah app sirf ${first('u')} par chalega"
            hasRel(r) -> "Pehle ${first('r')} pahucho, wahan pahunchte hi unblock"
            else -> "Abhi focus time hai"
        }
    }

    fun hasFine(c: Context) = c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    fun hasBg(c: Context) = Build.VERSION.SDK_INT < 29 || c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
    /** 0 = no permission, 1 = only while app is open, 2 = all the time (needed for background checking) */
    fun permLevel(c: Context) = if (!hasFine(c)) 0 else if (!hasBg(c)) 1 else 2

    /** Rules whose location must be watched right now (window active; release-only rules until reached). */
    fun watched(c: Context): List<Rule> {
        if (Gap.active(c)) return emptyList()
        return Store.rules(c).filter { it.on && it.lim == 0 && it.pls.isNotEmpty() && isActive(it, c) && (live(it) || !reached(c, it)) }
    }

    /** Phone Lock with a release place: reaching the place ends the lock. */
    fun lockWatched(c: Context) = !Gap.active(c) && Lock.until(c) > System.currentTimeMillis() && Lock.place(c) != 0

    // ---------- one-off fix (used when saving a place) ----------
    @SuppressLint("MissingPermission")
    fun fix(c: Context, cb: (Location?) -> Unit) {
        if (!hasFine(c)) { cb(null); return }
        val lm = c.getSystemService(LocationManager::class.java)
        val h = Handler(Looper.getMainLooper())
        var best: Location? = null
        var finished = false
        lateinit var l: LocationListener
        fun finish() {
            if (finished) return
            finished = true
            try { lm.removeUpdates(l) } catch (_: Throwable) {}
            cb(best)
        }
        l = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                val b = best
                if (b == null || loc.accuracy < b.accuracy) best = loc
                if (loc.accuracy <= 30f) finish()
            }
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
            @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        }
        var any = false
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try { if (lm.isProviderEnabled(p)) { lm.requestLocationUpdates(p, 0L, 0f, l, Looper.getMainLooper()); any = true } } catch (_: Throwable) {}
        }
        if (!any) { cb(null); return }
        h.postDelayed({ finish() }, 20_000L)
    }

    // ---------- background watcher (called every few seconds by KeepService) ----------
    private var mon: LocationListener? = null
    private var monMs = 0L
    private var pendSince = 0L

    private fun providersOn(lm: LocationManager) = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).any {
        try { lm.isProviderEnabled(it) } catch (_: Throwable) { false }
    }

    @SuppressLint("MissingPermission")
    fun tick(c: Context) {
        val w = watched(c)
        val lw = lockWatched(c)
        if (w.isEmpty() && !lw) { stop(c); pendSince = 0L; return }
        val lm = c.getSystemService(LocationManager::class.java)
        if (!hasFine(c) || !providersOn(lm)) { // can not see the location: live rules let go (fail open), release-only rules keep blocking
            stop(c)
            w.filter { live(it) }.forEach { setState(c, it, "o") }
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (pendSince == 0L) pendSince = now
        val want = if (now - pendSince < 600_000L) 15_000L else 60_000L // first 10 min fast, then battery friendly
        if (mon == null || monMs != want) {
            stop(c)
            val l = object : LocationListener {
                override fun onLocationChanged(loc: Location) { check(c, loc) }
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
                @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
            }
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try { if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, want, 0f, l, Looper.getMainLooper()) } catch (_: Throwable) {}
            }
            mon = l; monMs = want
        }
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try { lm.getLastKnownLocation(p)?.let { if (System.currentTimeMillis() - it.time < 120_000L) check(c, it) } } catch (_: Throwable) {}
        }
    }

    private fun stop(c: Context) {
        val l = mon ?: return
        mon = null; monMs = 0L
        try { c.getSystemService(LocationManager::class.java).removeUpdates(l) } catch (_: Throwable) {}
    }

    private fun inside(c: Context, loc: Location, ref: PlaceRef, grow: Boolean): Boolean {
        val p = Places.get(c, ref.id) ?: return false
        val res = FloatArray(1)
        Location.distanceBetween(loc.latitude, loc.longitude, p.lat, p.lng, res)
        return res[0] <= p.r * (if (grow) 1.2f else 1f)
    }

    private fun check(c: Context, loc: Location) {
        if (loc.accuracy > 300f) return
        var changed = false
        for (r in watched(c)) {
            if (r.pls.any { it.rel && inside(c, loc, it, false) } && !reached(c, r)) { markReached(c, r); changed = true }
            if (live(r)) {
                val was = state(c, r)
                // small margin stops the block flickering at the edge of a place
                val inU = r.pls.any { it.free && inside(c, loc, it, was == "u") }
                val inB = r.pls.any { it.block && inside(c, loc, it, was == "b") }
                val st = if (inU) "u" else if (inB) "b" else "o" // Unblock place wins over a Block place
                if (st != was) { setState(c, r, st); changed = true }
            }
        }
        if (lockWatched(c)) {
            val p = Places.get(c, Lock.place(c))
            if (p != null) {
                val res = FloatArray(1)
                Location.distanceBetween(loc.latitude, loc.longitude, p.lat, p.lng, res)
                if (res[0] <= p.r) { Lock.set(c, 0L); Lock.setPlace(c, 0); changed = true }
            }
        }
        if (changed) BlockService.poke()
    }
}
