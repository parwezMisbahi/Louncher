package com.focusly.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Calendar

/** A saved place. [r] = radius in metres that counts as "reached". */
data class Place(val id: Int, val name: String, val lat: Double, val lng: Double, val r: Int, val a: Int = 0)

object Places {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun all(c: Context): List<Place> = try {
        val a = JSONArray(sp(c).getString("places", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Place(o.getInt("id"), o.getString("n"), o.getDouble("lat"), o.getDouble("lng"), o.optInt("r", 150), o.optInt("a", 0))
        }
    } catch (_: Throwable) { emptyList() }
    fun save(c: Context, l: List<Place>) = sp(c).edit().putString("places", JSONArray(l.map {
        JSONObject().put("id", it.id).put("n", it.name).put("lat", it.lat).put("lng", it.lng).put("r", it.r).put("a", it.a)
    }).toString()).apply()
    fun get(c: Context, id: Int): Place? = all(c).find { it.id == id }
}

/**
 * A place linked to a rule. m = 'b': block only here, 'u': unblock only here (blocked everywhere else),
 * 'r': release - a running block ends as soon as you reach this place.
 */
data class PlaceRef(val id: Int, val m: Char) {
    val block get() = m == 'b'
    val free get() = m == 'u'
    val rel get() = m == 'r'
}

/**
 * Location-linked rules. Everything happens inside the rule's time window:
 *  - 'b' places: the rule blocks ONLY while the phone is inside one of them.
 *  - 'u' places: the rule blocks everywhere EXCEPT inside one of them (live: leave it and the block is back).
 *  - 'r' places: the rule blocks until the phone reaches one of them (or the window ends); then it is done for that window.
 * Priority: inside a 'u' place or reaching an 'r' place always wins over a 'b' place.
 */
object Presence {
    private fun sp(c: Context) = c.getSharedPreferences("focusly_pres", 0)

    /** Identifies the current occurrence of the rule's window (so state resets for the next day's window). */
    fun occKey(r: Rule): Long {
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        var day = LocalDate.now().toEpochDay()
        if (r.start > r.end && now < r.end) day -= 1
        return day * 1440L + r.start
    }

    fun hasBlock(r: Rule) = r.pls.any { it.block }
    fun hasFree(r: Rule) = r.pls.any { it.free }
    fun hasRel(r: Rule) = r.pls.any { it.rel }
    /** Rules whose blocking follows the live position (not just a one-time release). */
    fun live(r: Rule) = hasBlock(r) || hasFree(r)

    /** "b" = inside a Block place, "u" = inside an Unblock place, "o" = seen outside all places, "?" = never known yet -> BLOCKED. Location off = the LAST state stays. */
    private fun state(c: Context, r: Rule): String {
        val a = (sp(c).getString("in${r.id}", "") ?: "").split("|")
        return if (a.size == 2) a[1] else "?" // last state seen while location was on; "?" only if it was never known
    }
    private fun setState(c: Context, r: Rule, st: String) { sp(c).edit().putString("in${r.id}", "${occKey(r)}|$st").apply() }
    private fun reached(c: Context, r: Rule) = sp(c).getLong("r${r.id}", -1L) == occKey(r)
    private fun markReached(c: Context, r: Rule) { sp(c).edit().putLong("r${r.id}", occKey(r)).apply() }

    /** True = the location says "do not block this rule right now". */
    fun done(c: Context, r: Rule): Boolean {
        if (r.pls.isEmpty() || r.lim != 0) return false
        if (hasRel(r) && reached(c, r)) return true
        val st = state(c, r)
        if (st == "u") return true // inside an Unblock place: always wins
        // Block places: blocks only while inside one. Never-known ("?") stays blocked. Location off: last state stays.
        return hasBlock(r) && st == "o"
    }

    /** Short status for the UI: "wait", "reached", "in" (inside Block place), "free" (inside Unblock place), "out". */
    fun status(c: Context, r: Rule): String {
        if (r.pls.isEmpty() || r.lim != 0) return ""
        if (hasRel(r) && reached(c, r)) return "reached"
        val st = state(c, r)
        if (st == "u") return "free"
        if (st == "?") return "unk"
        if (hasBlock(r)) return if (st == "b") "in" else "out"
        return "wait"
    }

    /** Text shown on the block screen. */
    fun why(c: Context, r: Rule): String {
        if (live(r) && state(c, r) == "?") return "Abhi tak location check nahi hua - location on karo, tab tak block"
        val first = { m: Char -> r.pls.firstOrNull { it.m == m }?.let { Places.get(c, it.id)?.name } ?: "us jagah" }
        return when {
            hasBlock(r) -> "Is jagah par yah app block hai"
            hasFree(r) -> "Yah app sirf ${first('u')} par chalega"
            hasRel(r) -> "Pehle ${first('r')} pahucho, wahan pahunchte hi unblock"
            else -> "Abhi focus time hai"
        }
    }

    /** The notification-bar tile switches this: OFF = Focusly may not use location (location rules block until it is ON again). */
    fun locAllowed(c: Context) = c.getSharedPreferences("focusly", 0).getBoolean("locOk", true)
    fun setLocAllowed(c: Context, on: Boolean) {
        c.getSharedPreferences("focusly", 0).edit().putBoolean("locOk", on).apply()
        try { tick(c) } catch (_: Throwable) {}
        BlockService.poke()
    }

    fun hasFine(c: Context) = c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    fun hasBg(c: Context) = Build.VERSION.SDK_INT < 29 || c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
    /** 0 = no permission, 1 = only while app is open, 2 = all the time (needed for background checking) */
    fun permLevel(c: Context) = if (!hasFine(c)) 0 else if (!hasBg(c)) 1 else 2

    /** Rules whose location must be watched right now (window active; release-only rules until reached). */
    fun watched(c: Context): List<Rule> {
        if (Gap.active(c)) return emptyList()
        return Store.rules(c).filter { it.on && it.lim == 0 && it.pls.isNotEmpty() && isActive(it, c) && (live(it) || !reached(c, it)) }
    }

    /** Phone Lock with a release place: reaching the place ends the lock. */
    fun lockWatched(c: Context) = !Gap.active(c) && Lock.until(c) > System.currentTimeMillis() && Lock.pls(c).isNotEmpty()

    // ---------- Phone Lock with places (same three systems as the app rules) ----------
    private fun lockState(c: Context): String {
        val a = (sp(c).getString("lockst", "") ?: "").split("|")
        return if (a.size == 2) a[1] else "?"
    }
    private fun setLockState(c: Context, st: String) { sp(c).edit().putString("lockst", "${Lock.until(c)}|$st").apply() }

    /** True = the location says "the phone lock does not apply right now" (inside an Unlock place / outside every Lock place). */
    fun lockDone(c: Context): Boolean {
        val l = Lock.pls(c)
        if (l.isEmpty()) return false
        val st = lockState(c)
        if (st == "u") return true
        return l.any { it.block } && st == "o" // "?" (location unknown) never unlocks
    }

    /** "free", "in", "out", "unk" or "" - for the Phone Lock screen. */
    fun lockStatus(c: Context): String {
        val l = Lock.pls(c)
        if (l.isEmpty() || Lock.until(c) <= System.currentTimeMillis()) return ""
        val st = lockState(c)
        if (st == "u") return "free"
        if (st == "?") return "unk"
        return if (l.any { it.block }) (if (st == "b") "in" else "out") else ""
    }

    fun lockWhy(c: Context): String {
        val l = Lock.pls(c)
        if (l.isEmpty()) return "Phone lock chal raha hai"
        if (lockState(c) == "?") return "Abhi tak location check nahi hua - location on karo, tab tak lock"
        val first = { m: Char -> l.firstOrNull { it.m == m }?.let { Places.get(c, it.id)?.name } ?: "us jagah" }
        return when {
            l.any { it.block } -> "Is jagah par phone lock hai"
            l.any { it.free } -> "Phone sirf ${first('u')} par chalega"
            else -> "Pehle ${first('r')} pahucho, wahan pahunchte hi unlock"
        }
    }

    // ---------- one-off fix (used when saving a place) ----------
    /**
     * Collects fixes for up to 25 s and returns their accuracy-weighted AVERAGE (much closer to the real spot than a
     * single fix). Stops early after 6 good fixes (<= 15 m). The returned accuracy is the best single accuracy.
     */
    @SuppressLint("MissingPermission")
    fun fix(c: Context, cb: (Location?) -> Unit) {
        if (!hasFine(c)) { cb(null); return }
        val lm = c.getSystemService(LocationManager::class.java)
        val h = Handler(Looper.getMainLooper())
        val got = ArrayList<Location>()
        var finished = false
        lateinit var l: LocationListener
        fun finish() {
            if (finished) return
            finished = true
            try { lm.removeUpdates(l) } catch (_: Throwable) {}
            val use = got.filter { it.accuracy <= 60f }.ifEmpty { got }
            if (use.isEmpty()) { cb(null); return }
            var sw = 0.0; var la = 0.0; var ln = 0.0
            for (x in use) { val w = 1.0 / (maxOf(x.accuracy, 3f).toDouble().let { it * it }); sw += w; la += x.latitude * w; ln += x.longitude * w }
            val out = Location("avg")
            out.latitude = la / sw; out.longitude = ln / sw
            out.accuracy = use.minOf { it.accuracy }
            cb(out)
        }
        l = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                got.add(loc)
                if (got.count { it.accuracy <= 15f } >= 6) finish()
            }
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
            @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        }
        var any = false
        for (p in provs()) {
            try { if (lm.isProviderEnabled(p)) { lm.requestLocationUpdates(p, 0L, 0f, l, Looper.getMainLooper()); any = true } } catch (_: Throwable) {}
        }
        if (!any) { cb(null); return }
        h.postDelayed({ finish() }, 25_000L)
    }

    // ---------- background watcher (called every few seconds by KeepService) ----------
    private var mon: LocationListener? = null
    private var monMs = 0L
    private var pendSince = 0L

    /** GPS + network, and the fused provider where it exists (Android 12+): more devices give a fix indoors / on HyperOS. */
    fun provs(): List<String> = if (Build.VERSION.SDK_INT >= 31)
        listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.FUSED_PROVIDER)
    else listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)

    private fun providersOn(lm: LocationManager) = provs().any {
        try { lm.isProviderEnabled(it) } catch (_: Throwable) { false }
    }

    // ---------- diagnostics (shown by the "Location check" button in the Block tab) ----------
    @Volatile private var lastLoc: Location? = null
    @Volatile private var lastLocAt = 0L
    @Volatile private var lastSkip = ""
    @Volatile private var lastTickAt = 0L

    fun debug(c: Context): String {
        val sb = StringBuilder()
        val lvl = permLevel(c)
        sb.append("Permission: ").append(when (lvl) { 0 -> "NAHI (Location allow karo)"; 1 -> "sirf app khula ho tab (Hamesha allow karo!)"; else -> "Hamesha - ok" }).append('\n')
        val lm = c.getSystemService(LocationManager::class.java)
        sb.append("Focusly location tile: ").append(if (locAllowed(c)) "ON" else "OFF (location rules block)").append('\n')
        sb.append("Phone Location (GPS): ").append(if (providersOn(lm)) "ON" else "OFF - on karo").append('\n')
        val w = watched(c)
        sb.append("Abhi dekhe ja rahe rules: ").append(w.size).append('\n')
        if (w.isEmpty()) sb.append("(Koi location rule abhi time window ke andar nahi hai, isliye location check band hai)\n")
        sb.append("Service chal rahi: ").append(if (lastTickAt > 0 && System.currentTimeMillis() - lastTickAt < 30_000L) "haan" else "nahi / abhi tak tick nahi").append('\n')
        val l = lastLoc
        if (l == null) sb.append("Abhi tak koi location fix nahi mila.\n")
        else {
            sb.append("Last fix: ").append((System.currentTimeMillis() - lastLocAt) / 1000).append(" sec pehle, ")
                .append(l.provider).append(", accuracy ±").append(l.accuracy.toInt()).append(" m\n")
            if (lastSkip.isNotEmpty()) sb.append("Note: ").append(lastSkip).append('\n')
            val seen = HashSet<Int>()
            for (r in w) for (pr in r.pls) if (seen.add(pr.id)) {
                val pl = Places.get(c, pr.id) ?: continue
                val res = FloatArray(1)
                Location.distanceBetween(l.latitude, l.longitude, pl.lat, pl.lng, res)
                sb.append(pl.name).append(": ").append(res[0].toInt()).append(" m door (radius ").append(pl.r).append(" m) - ")
                    .append(if (res[0] <= pl.r) "ANDAR" else "BAHAR").append('\n')
            }
        }
        for (r in w) sb.append("Rule ").append(r.name).append(": ").append(status(c, r).ifEmpty { "-" }).append(if (ruleBlocking(r, c)) " (block chal raha)" else " (block nahi)").append('\n')
        return sb.toString().trim()
    }

    @SuppressLint("MissingPermission")
    fun tick(c: Context) {
        lastTickAt = System.currentTimeMillis()
        val w = watched(c)
        val lw = lockWatched(c)
        if (w.isEmpty() && !lw) { stop(c); pendSince = 0L; return }
        val lm = c.getSystemService(LocationManager::class.java)
        if (!locAllowed(c) || !hasFine(c) || !providersOn(lm)) { // can not see the location: keep the LAST state (block stays blocked, unblock stays unblocked)
            stop(c); lastGoodAt = 0L
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (pendSince == 0L) pendSince = now
        val want = if (now - pendSince < 600_000L) 10_000L else 45_000L // first 10 min fast, then battery friendly
        if (mon == null || monMs != want) {
            stop(c)
            val l = object : LocationListener {
                override fun onLocationChanged(loc: Location) { check(c, loc) }
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
                @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
            }
            for (p in provs()) {
                try { if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, want, 0f, l, Looper.getMainLooper()) } catch (_: Throwable) {}
            }
            mon = l; monMs = want
        }
        // also use the freshest cached fix of every provider (any app's recent fix), newest first
        val cached = provs().mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: Throwable) { null } }
            .filter { System.currentTimeMillis() - it.time < 180_000L }.sortedByDescending { it.time }
        cached.firstOrNull()?.let { check(c, it) }
    }

    @Volatile private var lastGoodAt = 0L

    private fun stop(c: Context) {
        val l = mon ?: return
        mon = null; monMs = 0L
        try { c.getSystemService(LocationManager::class.java).removeUpdates(l) } catch (_: Throwable) {}
    }

    private fun inside(c: Context, loc: Location, ref: PlaceRef, grow: Boolean): Boolean {
        val p = Places.get(c, ref.id) ?: return false
        val res = FloatArray(1)
        Location.distanceBetween(loc.latitude, loc.longitude, p.lat, p.lng, res)
        // GPS is never exact: count the current fix accuracy and the accuracy the place was saved with (each at most 30 m),
        // so a small radius (3-20 m) still works instead of always reading "outside"
        // Block places count an uncertain fix as "inside" (up to 100 m slack: better blocked than missed);
        // Unblock / reach places stay strict (15 m) so the unblock can not be cheated with a bad fix.
        val cap = if (ref.block) 100f else 15f
        val slack = minOf(loc.accuracy, cap) + minOf(p.a.toFloat(), cap)
        return res[0] <= p.r * (if (grow) 1.2f else 1f) + slack
    }

    private class Pend(val st: String, val n: Int, val t: Long)
    private val pend = HashMap<String, Pend>()
    /** A change of state (leaving / entering) must be seen in 2 DIFFERENT fixes in a row, so one bad GPS fix can not flip a block. */
    private fun confirm(key: String, was: String, st: String, t: Long): Boolean {
        if (st == was || was == "?") { pend.remove(key); return true }
        val p = pend[key]
        val n = if (p == null || p.st != st) 1 else if (p.t == t) p.n else p.n + 1
        pend[key] = Pend(st, n, t)
        return if (n >= 2) { pend.remove(key); true } else false
    }

    private fun check(c: Context, loc: Location) {
        if (lastLoc == null || loc.time >= (lastLoc?.time ?: 0L)) { lastLoc = loc; lastLocAt = System.currentTimeMillis() }
        if (loc.accuracy > 500f) { lastSkip = "Accuracy ±${loc.accuracy.toInt()} m bahut kam hai (500 m se zyada), isliye ignore. Khule mein / Wi-Fi on karo."; return }
        lastSkip = ""
        lastGoodAt = maxOf(lastGoodAt, SystemClock.elapsedRealtime() - (System.currentTimeMillis() - loc.time).coerceAtLeast(0L))
        var changed = false
        for (r in watched(c)) {
            if (r.pls.any { it.rel && inside(c, loc, it, false) } && !reached(c, r)) { markReached(c, r); changed = true }
            if (live(r)) {
                val was = state(c, r)
                // small margin stops the block flickering at the edge of a place
                val inU = r.pls.any { it.free && inside(c, loc, it, was == "u") }
                val inB = r.pls.any { it.block && inside(c, loc, it, was == "b") }
                val st = if (inU) "u" else if (inB) "b" else "o" // Unblock place wins over a Block place
                if (st != was && confirm("r${r.id}", was, st, loc.time)) { setState(c, r, st); changed = true }
                else if (st == was) pend.remove("r${r.id}")
            }
        }
        if (lockWatched(c)) {
            val l = Lock.pls(c)
            if (l.any { it.rel && inside(c, loc, it, false) }) { Lock.set(c, 0L); Lock.setPls(c, emptyList()); changed = true } // reached: lock ends
            else if (l.any { it.free || it.block }) {
                val was = lockState(c)
                val inU = l.any { it.free && inside(c, loc, it, was == "u") }
                val inB = l.any { it.block && inside(c, loc, it, was == "b") }
                val st = if (inU) "u" else if (inB) "b" else "o" // Unlock place wins over a Lock place
                if (st != was && confirm("lock", was, st, loc.time)) { setLockState(c, st); changed = true }
                else if (st == was) pend.remove("lock")
            }
        }
        if (changed) BlockService.poke()
    }
}

/** Live distance + compass heading for the UI (runs only while the app screen polls it; stops itself after ~20 s idle). */
object Live : LocationListener, android.hardware.SensorEventListener {
    @Volatile private var loc: Location? = null
    @Volatile private var locAt = 0L
    @Volatile private var heading = -1f
    @Volatile private var lastPoll = 0L
    private var running = false
    private var app: Context? = null
    private val h = Handler(Looper.getMainLooper())
    private val rot = FloatArray(9)
    private val ori = FloatArray(3)
    private val stopper = object : Runnable {
        override fun run() {
            if (System.currentTimeMillis() - lastPoll > 20_000L) stop() else h.postDelayed(this, 5_000L)
        }
    }

    @SuppressLint("MissingPermission")
    private fun start(c: Context) {
        if (running) return
        app = c.applicationContext
        running = true
        h.post {
            try {
                val lm = c.getSystemService(LocationManager::class.java)
                for (p in Presence.provs()) try {
                    if (lm.isProviderEnabled(p)) {
                        lm.requestLocationUpdates(p, 1000L, 0f, this, Looper.getMainLooper())
                        lm.getLastKnownLocation(p)?.let { if (loc == null || it.time > (loc?.time ?: 0)) { loc = it; locAt = System.currentTimeMillis() } }
                    }
                } catch (_: Throwable) {}
                val sm = c.getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
                sm.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR)?.let {
                    sm.registerListener(this, it, android.hardware.SensorManager.SENSOR_DELAY_UI)
                }
            } catch (_: Throwable) {}
            h.postDelayed(stopper, 5_000L)
        }
    }

    private fun stop() {
        running = false
        val c = app ?: return
        try { c.getSystemService(LocationManager::class.java).removeUpdates(this) } catch (_: Throwable) {}
        try { (c.getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager).unregisterListener(this) } catch (_: Throwable) {}
        heading = -1f
    }

    override fun onLocationChanged(l: Location) {
        val o = loc
        if (o == null || l.accuracy <= o.accuracy + 30f || l.time - o.time > 8_000L) { loc = l; locAt = System.currentTimeMillis() }
    }
    @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    override fun onProviderEnabled(p: String) {}
    override fun onProviderDisabled(p: String) {}
    override fun onAccuracyChanged(s: android.hardware.Sensor?, a: Int) {}
    override fun onSensorChanged(e: android.hardware.SensorEvent) {
        try {
            android.hardware.SensorManager.getRotationMatrixFromVector(rot, e.values)
            android.hardware.SensorManager.getOrientation(rot, ori)
            var d = Math.toDegrees(ori[0].toDouble()).toFloat()
            val l = loc
            if (l != null) d += android.hardware.GeomagneticField(l.latitude.toFloat(), l.longitude.toFloat(), l.altitude.toFloat(), System.currentTimeMillis()).declination
            heading = (d + 360f) % 360f
        } catch (_: Throwable) {}
    }

    /** JSON: {ok, acc, age, hd, p:[{id,d,b}]} - d metres, b bearing 0..360 from true north. */
    fun json(c: Context): String {
        lastPoll = System.currentTimeMillis()
        val o = JSONObject()
        if (Presence.permLevel(c) == 0) return o.put("ok", false).put("why", "perm").toString()
        start(c)
        val l = loc ?: return o.put("ok", false).put("why", "nofix").toString()
        o.put("ok", true).put("acc", l.accuracy.toInt()).put("age", ((System.currentTimeMillis() - locAt) / 1000).toInt()).put("hd", heading.toInt())
        val a = JSONArray()
        val res = FloatArray(2)
        for (p in Places.all(c)) {
            Location.distanceBetween(l.latitude, l.longitude, p.lat, p.lng, res)
            a.put(JSONObject().put("id", p.id).put("d", res[0].toInt()).put("b", ((res[1] + 360f) % 360f).toInt()))
        }
        return o.put("p", a).toString()
    }
}
