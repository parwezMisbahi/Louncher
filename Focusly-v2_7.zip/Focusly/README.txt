Focusly - build + update
------------------------
UI: app/src/main/assets/index.html (WebView). Isko browser mein bhi khol sakte ho (demo data ke saath).
Native engine (alarm, reminder, app block, lock): Core.kt / Block.kt / Phase2.kt, bridge: MainActivity.kt

Update bina uninstall: har build focusly.jks se sign hota hai (same key) aur versionCode har build pe
badhta hai, isliye naya APK purane ke upar install ho jata hai. focusly.jks ko kabhi delete/change mat karna
aur GitHub pe bhi isi file ke saath push karna.

Build: GitHub pe push karo -> Actions -> "Build Focusly APK" -> Focusly-debug-apk.
Local: gradle assembleDebug  (Gradle 8.9, JDK 17)

Block / Lock ke liye zaroori: phone Settings > Accessibility > Focusly ko ON karna hota hai.
Block system ab Docera jaisa hai: blocked app ke window ke upar overlay ("app block hai" + sirf Home button), split-screen / floating window par bhi.
Optional auto-enable: adb shell pm grant com.focusly.app android.permission.WRITE_SECURE_SETTINGS

Naya (v2.2):
- Alarm / Reminder / Goal reminder par "Poori screen block" option: fix time ke liye poori screen block (sirf emergency 5 min x 2 roz).
- Goal: category (Sehat/Padhai/Fitness/Kaam/Aur), kab se kab tak time window, target ke hisaab se reminders evenly spread; notification par "Ho gaya +N" button.
- Chalte hue block ko band/delete nahi kar sakte (UI aur native dono mein roka gaya).

v2.3:
- Block: sab installed apps ki list me se ek ya zyada apps select (Sab chuno / Clear / search).
- Daily limit rule: "roz X minute" - Focusly khud foreground time ginta hai, limit poori hote hi app block (raat 12 baje khulta).
- Goal ke saath app block: goal ka progress poora hone tak chuni apps block.
- Strict mode (Block tab): block chalte waqt Focusly ki Settings pages / uninstall band (Device Admin + settings guard).
- Blocker band ho jaye to notification aata hai (tap -> Accessibility settings).

v2.4 (HyperOS fix):
- KeepService: foreground notification + sticky restart, so recents se hatane par blocker / alarm band na ho.
- Home / Lock tab par "Phone settings" card: Autostart, Battery (No restrictions), App info shortcuts.
- Boot / app-update par alarms + service dobara chalu.
Phone mein ek baar zaroor: Autostart ON, Battery No restrictions, recents mein Focusly lock, App info > menu > Allow restricted settings.

v2.4 update: KeepService ab Docera jaisa 2nd blocker bhi hai (Usage access + Display over other apps).
Accessibility band ho (recents se hatane par) tab bhi blocked app par overlay aata hai, aur screen-block / daily limit chalte hain.
Home / Lock tab ke card se: Usage access, Overlay, Autostart, Battery, App info.

"Kabhi block nahi" apps: Block tab / Lock tab mein "+ App jodo". Ye apps Phone Lock, "Saare apps" rules, poori screen block aur goal "sab apps" block se bachte hain
(padhne wale apps ke liye). Kisi app ka apna alag rule ho to wo lagta hai. Block chalte waqt list mein naye apps nahi jud sakte (sirf hat sakte hain).

Settings: header ke upar naya Settings button. Phone settings (Usage/Overlay/Autostart/Battery/App info), Strict mode aur "Kabhi block nahi" apps ab wahin hain.

v2.5 (Plan B: galti se laga block hatana):
- "Sab block hatao": har 2 ghante mein 1 baar, 5 minute ke liye POORA block system band (app rules, daily limit, goal link, Phone lock, poori screen block).
- Block tab ke upar card + block screen par button (2 baar tap karna padta hai). Window ke dauran rule off / delete ho sakta hai, Phone lock hat sakta hai, Strict mode band ho sakta hai.
- 5 min baad block wapas lag jata hai. Agla window pehle window shuru hone ke 2 ghante baad khulta hai.
- Time badalna ho to Phase2.kt mein object Gap: MINUTES (5) aur EVERY_MIN (120).

v2.6 (Jagah / location wale rules):
- Block tab > "Jagahen": jagah jodo (naam + "Abhi yahan ki location lo" + radius 100-500 m).
- Schedule rule banate waqt "Jagah (optional)" chuno: rule ke time par block lagta hai aur us jagah pahunchte hi unblock ho jata hai (us din ke window ke liye). Window khatam hone par bhi block hat jata hai.
- Use 1 (namaz): "Saare apps" + 20 minute ka time + masjid ki jagah. Use 2 (class): social media apps + subah se raat tak ka time + class ki jagah: class pahunche to unblock, nahi gaye to din bhar block.
- Location check sirf tab chalta hai jab koi jagah-wala block lag raha ho (pehle 10 min har 15 sec, phir har 60 sec) taaki battery kam lage.
- Permission: Location ke liye "Hamesha allow" (Allow all the time) dena zaroori hai, aur phone ki Location (GPS) ON honi chahiye.
- Block chalte waqt jagah edit/delete nahi ho sakti (warna jagah apne paas move karke cheating ho jati). "Sab block hatao" window mein sab ho sakta hai.

v2.7 (Block jagah + Unblock jagah):
- Rule mein har jagah ke liye 3 option: Koi nahi / Unblock / Block.
- Sirf Unblock jagah: window mein block rehta hai, wahan pahunchte hi unblock (us din ke window ke liye).
- Block jagah chuni ho: app sirf us jagah ke andar block hota hai (window ke time mein). Bahar nikalte hi block hat jata hai.
- Dono ek saath: UNBLOCK KO PRIORITY. Unblock jagah ke andar block jagah disturb nahi karti (jaise bade Block area ke andar chhota Unblock area).
- Block-jagah wale rule ka window chalte waqt rule edit/delete nahi hota (bahar hone par bhi). "Sab block hatao" window mein sab ho sakta hai.
- Location dikhne band ho jaye (GPS off / permission hati) to Block-jagah wale rule block nahi karte.
