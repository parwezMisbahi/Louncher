plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.focusly.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.focusly.app"
        minSdk = 26
        targetSdk = 34
        // Always increasing (build time) so every new build installs as an UPDATE.
        // GitHub workflow passes -PverCode=<epoch seconds>; local builds use the same unit.
        versionCode = (findProperty("verCode") as String?)?.toIntOrNull() ?: (System.currentTimeMillis() / 1000L).toInt()
        versionName = "2.7"
    }

    // Fixed signing key (focusly.jks in the project root). Every build - debug or release -
    // is signed with this same key, so a new APK installs over the old one without uninstalling
    // and without losing data.
    val ks = rootProject.file("focusly.jks")
    signingConfigs {
        if (ks.exists()) {
            create("focusly") {
                storeFile = ks
                storePassword = "focusly123"
                keyAlias = "focusly"
                keyPassword = "focusly123"
            }
        }
    }
    buildTypes {
        debug { if (ks.exists()) signingConfig = signingConfigs.getByName("focusly") }
        release {
            if (ks.exists()) signingConfig = signingConfigs.getByName("focusly")
            isMinifyEnabled = false
        }
    }

    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
