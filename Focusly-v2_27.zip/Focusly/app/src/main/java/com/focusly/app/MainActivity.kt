package com.focusly.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.app.admin.DeviceAdminReceiver
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

fun newId() = (System.currentTimeMillis() % 100000).toInt() + 1

/**
 * The whole UI lives in assets/index.html (same design as the preview).
 * Kotlin only hosts it and exposes the real alarm / reminder / block / lock engine
 * to the page through the "Native" JavaScript bridge.
 */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var rootView: android.view.View? = null
    private var barColor = 0xFF0B1517.toInt()
    private var loaded = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setBars(true)
        KeepService.start(this)
        web = WebView(this).apply {
            setBackgroundColor(0xFF0B1517.toInt())
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = false
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                textZoom = 100
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean = true
                override fun shouldInterceptRequest(v: WebView?, r: WebResourceRequest?): WebResourceResponse? {
                    val u = r?.url ?: return null
                    if (u.host == "appicon.focusly") return appIcon(u.lastPathSegment?.removeSuffix(".png") ?: "")
                    return null
                }
                override fun onPageFinished(v: WebView?, url: String?) { loaded = true }
            }
            addJavascriptInterface(Bridge(), "Native")
        }
        val root = android.widget.FrameLayout(this)
        rootView = root
        root.setBackgroundColor(barColor)
        root.addView(web, android.widget.FrameLayout.LayoutParams(-1, -1))
        root.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = ins.getInsets(android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout() or android.view.WindowInsets.Type.ime())
                v.setPadding(b.left, b.top, b.right, b.bottom)
                android.view.WindowInsets.CONSUMED
            } else ins
        }
        setContentView(root)
        if (Cfg.bool(this, "alk", false)) showLockCover()
        applyLockFlag()
        web.loadUrl("file:///android_asset/index.html")
    }

    // ---------- Focusly lock (phone PIN / pattern / fingerprint) ----------
    private var lockCover: View? = null
    private var lastLeft = 0L
    private var unlocked = false
    private var lockAsking = false

    private fun applyLockFlag() {
        if (Cfg.bool(this, "alk", false)) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
    }
    private fun showLockCover() {
        if (lockCover != null) return
        val v = View(this); v.setBackgroundColor(barColor); v.isClickable = true
        (rootView as? android.widget.FrameLayout)?.addView(v, android.widget.FrameLayout.LayoutParams(-1, -1))
        lockCover = v
    }
    private fun dropLockCover() { lockCover?.let { (rootView as? android.widget.FrameLayout)?.removeView(it) }; lockCover = null }

    private fun gate() {
        if (!Cfg.bool(this, "alk", false)) { dropLockCover(); return }
        val km = getSystemService(android.app.KeyguardManager::class.java)
        if (km == null || !km.isDeviceSecure) { dropLockCover(); return }
        if (lockAsking) return
        if (unlocked && System.currentTimeMillis() - lastLeft < 20_000L) { dropLockCover(); return }
        unlocked = false
        showLockCover()
        @Suppress("DEPRECATION")
        val i = km.createConfirmDeviceCredentialIntent("Focusly", "Unlock to open Focusly")
        if (i == null) { dropLockCover(); return }
        lockAsking = true
        try { @Suppress("DEPRECATION") startActivityForResult(i, 77) } catch (_: Throwable) { lockAsking = false; dropLockCover() }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            lockAsking = false
            if (resultCode == RESULT_OK) { unlocked = true; lastLeft = System.currentTimeMillis(); dropLockCover() } else finish()
        }
    }

    override fun onPause() { lastLeft = System.currentTimeMillis(); super.onPause() }

    override fun onResume() {
        super.onResume()
        gate()
        KeepService.start(this)
        if (!BlockService.connected && Blocker.anyConfigured(this)) Blocker.tryEnableService(this)
        if (loaded) web.evaluateJavascript("window.focuslyReload&&focuslyReload()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.focuslyBack?focuslyBack():false") { if (it != "true") finish() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // normal location granted -> straight away ask for "all the time" (needed for background blocking)
        if (requestCode == 2 && Presence.hasFine(this) && !Presence.hasBg(this) && Build.VERSION.SDK_INT >= 29) {
            try { requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 3) } catch (_: Throwable) {}
        }
        if (loaded) web.evaluateJavascript("window.focuslyLocPerm&&focuslyLocPerm()", null)
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }

    private fun adminOn() = try { getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(this, AdminRx::class.java)) } catch (_: Exception) { false }

    @Suppress("DEPRECATION")
    private fun setBars(dark: Boolean) {
        val col = if (dark) 0xFF0B1517.toInt() else 0xFFEEF5F3.toInt()
        barColor = col
        rootView?.setBackgroundColor(col)
        try { window.statusBarColor = col; window.navigationBarColor = col } catch (_: Throwable) {}
        var f = window.decorView.systemUiVisibility
        f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
        else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
    }

    private fun appIcon(pkg: String): WebResourceResponse {
        return try {
            val d = packageManager.getApplicationIcon(pkg)
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 96, 96); d.draw(Canvas(bmp))
            val out = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            WebResourceResponse("image/png", null, 200, "OK", mapOf("Cache-Control" to "max-age=3600"), ByteArrayInputStream(out.toByteArray()))
        } catch (e: Exception) {
            WebResourceResponse("image/png", null, 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        }
    }

    inner class Bridge {
        @JavascriptInterface fun getState(): String {
            val c = applicationContext
            return JSONObject()
                .put("alarms", JSONArray(Store.alarms(c).map {
                    JSONObject().put("id", it.id).put("h", it.hour).put("m", it.minute)
                        .put("d", JSONArray(it.days.sorted())).put("l", it.label).put("on", it.on).put("bk", it.blk)
                }))
                .put("rems", JSONArray(Store.reminders(c).map {
                    JSONObject().put("id", it.id).put("t", it.title).put("at", it.at).put("daily", it.daily).put("on", it.on).put("bk", it.blk)
                }))
                .put("rules", JSONArray(Store.rules(c).map {
                    JSONObject().put("id", it.id).put("pkg", it.pkg).put("n", it.name).put("s", it.start).put("e", it.end)
                        .put("d", JSONArray(it.days.sorted())).put("on", it.on)
                        .put("lim", it.lim).put("used", (Usage.get(c, it.pkg) / 60_000L).toInt())
                        .put("pls", JSONArray(it.pls.map { p -> JSONObject().put("id", p.id).put("m", p.m.toString()) }))
                        .put("d1", it.d1).put("d2", it.d2).put("gp", it.gaps)
                        .put("done", Presence.done(c, it)).put("ls", Presence.status(c, it)).put("lk", ruleLocked(it, c))
                }))
                .put("goals", JSONArray(GoalStore.load(c).map {
                    JSONObject().put("id", it.id).put("n", it.name).put("u", it.unit).put("t", it.target).put("st", it.step)
                        .put("p", it.progress).put("day", it.day).put("streak", it.streak).put("last", it.lastDone)
                        .put("c", it.cat).put("r", it.rem).put("ws", it.ws).put("we", it.we).put("bk", it.blk)
                        .put("lp", JSONArray(it.lp.toList())).put("ln", it.ln)
                }))
                .put("allow", JSONArray(Allow.get(c).map { p ->
                    val n = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString() } catch (_: Exception) { p }
                    JSONObject().put("p", p).put("n", n)
                }))
                .put("strict", Strict.wanted(c) && adminOn())
                .put("lockUntil", Lock.until(c)).put("lockPl", 0)
                .put("lockPls", JSONArray(Lock.pls(c).map { p -> JSONObject().put("id", p.id).put("m", p.m.toString()) })).put("lockLs", Presence.lockStatus(c))
                .put("places", JSONArray(Places.all(c).map { p ->
                    JSONObject().put("id", p.id).put("n", p.name).put("lat", p.lat).put("lng", p.lng).put("r", p.r).put("a", p.a).put("by", p.by).put("bd", JSONArray(p.bd.split(",").mapNotNull { x -> x.toIntOrNull() }))
                }))
                .put("plog", PlaceLog.week(c)).put("x", cfgJson(c))
                .put("loc", Presence.permLevel(c)).put("locOk", Presence.locAllowed(c))
                .put("fr", JSONObject().put("typing", Friction.typing(c)).put("wait", Friction.wait(c)).put("quick", Pomo.quickMin(c)))
                .put("pomo", Pomo.st(c).let { s -> JSONObject().put("on", s.running).put("focus", s.focus).put("left", s.leftMs).put("round", s.round).put("rounds", s.rounds).put("f", s.f).put("b", s.b) })
                .put("gap", JSONObject().put("until", Gap.until(c)).put("next", Gap.next(c)).put("min", Gap.MINUTES).put("every", Gap.EVERY_MIN / 60))
                .toString()
        }

        private fun cfgJson(c: android.content.Context): JSONObject {
            val km = getSystemService(android.app.KeyguardManager::class.java)
            return JSONObject()
                .put("bed", JSONObject().put("on", Bed.on(c)).put("s", Bed.s(c)).put("e", Bed.e(c)).put("dim", Bed.dim(c))
                    .put("d", JSONArray(Bed.days(c).sorted())).put("active", Bed.active(c)))
                .put("alk", Cfg.bool(c, "alk", false)).put("secure", km?.isDeviceSecure == true)
                .put("wk", Cfg.bool(c, "wk_on", true)).put("plogOn", PlaceLog.logOn(c))
        }

        /** Usage report: last 7 days of screen time, top apps, blocks. */
        @JavascriptInterface fun report(): String = try { Report.week(applicationContext).toString() } catch (e: Throwable) { "{}" }

        /** Bedtime settings. Returns "ok" or "locked" (can not be changed while bedtime is running). */
        @JavascriptInterface fun setBed(on: Boolean, s: Int, e: Int, days: String, dim: Boolean): String {
            val c = applicationContext
            if (Bed.active(c) && !Gap.active(c)) return "locked"
            Bed.set(c, on, s, e, days, dim)
            if (on && !BlockService.connected) Blocker.tryEnableService(c)
            return "ok"
        }

        /** Simple switches: "alk" (Focusly lock), "wk" (weekly summary), "plog" (time log). Returns "ok" / "nolock". */
        @JavascriptInterface fun setSwitch(key: String, on: Boolean): String {
            val c = applicationContext
            when (key) {
                "alk" -> {
                    if (on && getSystemService(android.app.KeyguardManager::class.java)?.isDeviceSecure != true) return "nolock"
                    Cfg.setBool(c, "alk", on); runOnUiThread { applyLockFlag() }
                }
                "wk" -> Cfg.setBool(c, "wk_on", on)
                "plog" -> Cfg.setBool(c, "plog_on", on)
                else -> return "bad"
            }
            return "ok"
        }

        @JavascriptInterface fun refreshWidgets() { InfoWidget.refresh(applicationContext, true) }

        /** 0 = no location permission, 1 = only while app open, 2 = all the time */
        @JavascriptInterface fun locPerm(): Int = Presence.permLevel(applicationContext)

        /** Asks for location permission (first normal, then "all the time" which Android asks for separately). */
        @JavascriptInterface fun askLoc() {
            runOnUiThread {
                try {
                    val c = applicationContext
                    if (!Presence.hasFine(c)) requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 2)
                    else if (!Presence.hasBg(c) && Build.VERSION.SDK_INT >= 29) requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 3)
                } catch (_: Throwable) {}
            }
        }

        /** Gets the current location; the result comes back as window.onLoc(lat, lng, accuracy) or window.onLocErr(msg). */
        @JavascriptInterface fun locNow() {
            runOnUiThread {
                Presence.fix(this@MainActivity) { loc ->
                    if (loc == null) web.evaluateJavascript("window.onLocErr&&onLocErr('Could not get location. Turn on phone Location (GPS) and try again.')", null)
                    else web.evaluateJavascript("window.onLoc&&onLoc(${loc.latitude},${loc.longitude},${loc.accuracy})", null)
                }
            }
        }

        /** Pomodoro: false if one is already running. */
        @JavascriptInterface fun pomoStart(f: Int, b: Int, n: Int): Boolean = Pomo.start(applicationContext, f, b, n)
        /** false while a focus phase is running (can not be stopped). */
        @JavascriptInterface fun pomoStop(): Boolean = Pomo.stop(applicationContext)

        /** Unblock friction. While a block is running it can only be made stricter. */
        @JavascriptInterface fun setFriction(typing: Boolean, waitMin: Int, quick: Int) {
            val c = applicationContext
            val busy = Blocker.anyActive(c)
            Friction.set(c, if (busy) (Friction.typing(c) || typing) else typing, if (busy) maxOf(Friction.wait(c), waitMin) else waitMin)
            Pomo.setQuickMin(c, quick)
        }

        @JavascriptInterface fun setLocOk(on: Boolean) { Presence.setLocAllowed(applicationContext, on) }

        /** Android 13+: asks the user to add the "Focusly location" tile to the notification bar. Returns false when the phone can not do that (add it by hand: Edit in the notification panel). */
        @JavascriptInterface fun addTile(): Boolean {
            if (Build.VERSION.SDK_INT < 33) return false
            runOnUiThread {
                try {
                    getSystemService(android.app.StatusBarManager::class.java).requestAddTileService(
                        ComponentName(this@MainActivity, LocTile::class.java), "Focusly location",
                        android.graphics.drawable.Icon.createWithResource(this@MainActivity, R.drawable.ic_tile), mainExecutor) { }
                } catch (_: Throwable) {}
            }
            return true
        }

        /** Live distance/bearing to every saved place (poll about every 1.5 s while the Block/Lock tab is open). */
        @JavascriptInterface fun liveLoc(): String = try { Live.json(applicationContext) } catch (e: Throwable) { "{\"ok\":false}" }

        /** Plain-text report of the location system (permission, GPS, last fix, distance to places, rule state). */
        @JavascriptInterface fun locDebug(): String = try { Presence.debug(applicationContext) } catch (e: Throwable) { "Error: ${e.message}" }

        /** "ok" = all blocks are off for Gap.MINUTES now; "wait" = the next window is not open yet. */
        @JavascriptInterface fun gapUse(): String = if (Gap.use(applicationContext)) "ok" else "wait"

        @JavascriptInterface fun save(json: String) {
            val c = applicationContext
            val o = JSONObject(json)
            fun days(a: JSONArray) = (0 until a.length()).map { a.getInt(it) }.toSet()
            fun <T> arr(k: String, f: (JSONObject) -> T): List<T> {
                val a = o.optJSONArray(k) ?: return emptyList()
                return (0 until a.length()).map { f(a.getJSONObject(it)) }
            }
            // cancel everything that was scheduled, store the new lists, schedule again
            Store.alarms(c).forEach { Sched.cancel(c, "a", it.id) }
            Store.reminders(c).forEach { Sched.cancel(c, "r", it.id) }
            GoalStore.load(c).forEach { GoalSched.cancel(c, it) }
            Store.saveAlarms(c, arr("alarms") { Alarm(it.getInt("id"), it.getInt("h"), it.getInt("m"), days(it.getJSONArray("d")), it.optString("l", ""), it.getBoolean("on"), it.optInt("bk", 0).coerceIn(0, 180)) })
            Store.saveReminders(c, arr("rems") { Reminder(it.getInt("id"), it.getString("t"), it.getLong("at"), it.getBoolean("daily"), it.getBoolean("on"), it.optInt("bk", 0).coerceIn(0, 180)) })
            // A block that is running right now can NOT be switched off, deleted or shortened from the UI.
            val gap = Gap.active(c) // unblock window: rules / goals / lock may be loosened or deleted
            val activeOld = if (gap) emptyList() else Store.rules(c).filter { ruleLocked(it, c) }
            val oldGoals = GoalStore.load(c)
            val incoming = arr("rules") { Rule(it.getInt("id"), it.getString("pkg"), it.getString("n"), it.getInt("s"), it.getInt("e"), days(it.getJSONArray("d")), it.getBoolean("on"), it.optInt("lim", 0).coerceIn(0, 1440),
                (it.optJSONArray("pls")?.let { a -> (0 until a.length()).mapNotNull { k -> a.optJSONObject(k)?.let { q -> PlaceRef(q.getInt("id"), q.optString("m", "r").firstOrNull() ?: 'r') } } } ?: emptyList()), it.optLong("d1", 0L), it.optLong("d2", 0L), it.optString("gp", "")) }
            val kept = incoming.map { r -> activeOld.find { it.id == r.id } ?: r } + activeOld.filter { o -> incoming.none { it.id == o.id } }
            // places used by a blocking rule can not be edited or deleted (else you could move the place to where you are)
            val lockRunning = !gap && Lock.until(c) > System.currentTimeMillis()
            val lockedPl = activeOld.flatMap { r -> r.pls.map { p -> p.id } }.toSet() + (if (lockRunning) Lock.pls(c).map { it.id }.toSet() else emptySet())
            val oldPlaces = Places.all(c)
            val placesNew = if (o.has("places")) {
                val inc = arr("places") { Place(it.getInt("id"), it.getString("n"), it.getDouble("lat"), it.getDouble("lng"), it.optInt("r", 150).coerceIn(3, 5000), it.optInt("a", 0).coerceIn(0, 1000), it.optInt("by", -1).coerceIn(-1, 1439),
                    (it.optJSONArray("bd")?.let { a -> (0 until a.length()).map { k -> a.getInt(k) } } ?: emptyList()).joinToString(",")) }
                inc.map { p -> if (p.id in lockedPl) (oldPlaces.find { it.id == p.id } ?: p) else p } +
                    oldPlaces.filter { op -> op.id in lockedPl && inc.none { it.id == op.id } }
            } else oldPlaces
            Places.save(c, placesNew)
            val pids = placesNew.map { it.id }.toSet()
            Store.saveRules(c, kept.map { r -> r.copy(pls = r.pls.filter { p -> p.id in pids }) })
            val newGoals = arr("goals") { Goal(it.getInt("id"), it.getString("n"), it.optString("u", ""), it.getInt("t"), it.getInt("st"), it.getInt("p"), it.getLong("day"), it.getInt("streak"), it.getLong("last"),
                it.optString("c", ""), it.optBoolean("r", false), it.optInt("ws", 420), it.optInt("we", 1380), it.optInt("bk", 0).coerceIn(0, 180),
                (it.optJSONArray("lp")?.let { l -> (0 until l.length()).map { k -> l.getString(k) } } ?: emptyList()).toSet(), it.optInt("ln", 0)) }
            // a goal whose app-block is running can not be deleted or loosened until the goal is done
            val lockedGoals = if (gap) emptyList() else oldGoals.filter { it.linkActive() }
            val goalsKept = newGoals.map { g -> lockedGoals.find { it.id == g.id }?.let { o -> g.copy(lp = o.lp, ln = o.ln, rem = o.rem, ws = o.ws) } ?: g } +
                lockedGoals.filter { o -> newGoals.none { it.id == o.id } }
            GoalStore.save(c, goalsKept)
            Lock.set(c, if (gap) o.optLong("lockUntil", 0) else maxOf(o.optLong("lockUntil", 0), Lock.until(c))) // a running lock can not be shortened (except in an unblock window)
            if (!lockRunning) {
                val lp = if (Lock.until(c) > System.currentTimeMillis()) o.optJSONArray("lockPls")?.let { a ->
                    (0 until a.length()).mapNotNull { k -> a.optJSONObject(k)?.let { q -> PlaceRef(q.getInt("id"), q.optString("m", "r").firstOrNull() ?: 'r') } }
                } ?: emptyList() else emptyList()
                Lock.setPls(c, lp.filter { p -> p.id in pids })
            }
            // "never block" apps: while a block is running the list can only get shorter
            o.optJSONArray("allow")?.let { a ->
                val inc = (0 until a.length()).mapNotNull { k -> a.optJSONObject(k)?.optString("p")?.takeIf { it.isNotEmpty() } }.toSet()
                Allow.set(c, if (Blocker.anyActive(c)) inc.intersect(Allow.get(c)) else inc)
            }
            Sched.armAll(c)
        }

        @JavascriptInterface fun apps(): String {
            val pm = packageManager
            val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
            return JSONArray(l.map { JSONObject().put("p", it.first).put("n", it.second) }).toString()
        }

        @JavascriptInterface fun strictOn(): Boolean = Strict.wanted(applicationContext) && adminOn()

        /** "ok", "admin" (Android asks to activate device admin first), "locked" (a block is running) */
        @JavascriptInterface fun setStrict(on: Boolean): String {
            val c = applicationContext
            if (on) {
                Strict.set(c, true)
                if (!adminOn()) {
                    runOnUiThread { try { startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(c, AdminRx::class.java))
                        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Strict mode: protects Focusly from being uninstalled while a block is active.")) } catch (_: Exception) {} }
                    return "admin"
                }
                return "ok"
            }
            if (Blocker.anyActive(c)) return "locked"
            Strict.set(c, false)
            try { c.getSystemService(DevicePolicyManager::class.java).removeActiveAdmin(ComponentName(c, AdminRx::class.java)) } catch (_: Exception) {}
            return "ok"
        }

        @JavascriptInterface fun accOn(): Boolean = accessibilityOn(applicationContext)

        @JavascriptInterface fun openAccessibility() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface fun usageOn(): Boolean = KeepService.hasUsage(applicationContext)
        @JavascriptInterface fun overlayOn(): Boolean = KeepService.hasOverlay(applicationContext)
        @JavascriptInterface fun openUsage() { runOnUiThread { Oem.usage(this@MainActivity) } }
        @JavascriptInterface fun openOverlay() { runOnUiThread { Oem.overlay(this@MainActivity) } }
        @JavascriptInterface fun openAutostart() { runOnUiThread { Oem.autostart(this@MainActivity) } }
        @JavascriptInterface fun openBattery() { runOnUiThread { Oem.battery(this@MainActivity) } }
        @JavascriptInterface fun openAppInfo() { runOnUiThread { Oem.appInfo(this@MainActivity) } }
        @JavascriptInterface fun batteryOk(): Boolean = Oem.batteryOk(applicationContext)

        @JavascriptInterface fun theme(dark: Boolean) { runOnUiThread { setBars(dark) } }
    }
}

/** Empty device admin: while it is active Android refuses to uninstall Focusly (used by Strict mode). */
class AdminRx : DeviceAdminReceiver()
